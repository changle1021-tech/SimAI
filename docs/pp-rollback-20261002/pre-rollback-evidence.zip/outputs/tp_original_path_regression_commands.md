# TP legacy regression: recorded reproduction commands

These are the 12 commands recorded for this Llama-2 TP regression. They are transcribed from the archived `*.launch.json` records; this document does not execute them.

The recorded output and cache locations already contain this run. Do not replay these commands unchanged: use a fresh run root, cache directory, and output directory, and update only the path fields needed for that new run. The archived runtime snapshot and its restoration scope are documented in [original_runtime_provenance.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/original_runtime_provenance.json); the outer driver is [tp_legacy_regression_20261002_driver.py](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/external_run_records/tp_legacy_regression_20261002_driver.py).

These commands launch Vidur replay/config drivers, not the original vLLM services. For the user-facing vLLM server/client commands and earlier sampling commands, see the prior [recorded command document](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/llama2_tp4_mixed_test_commands.md).

For each record, `PYTHONPATH` and `env_overrides` below are the launch-record values. `PYTHONPATH: null` would mean no explicit override and inheritance from the process environment. Commands are presented as `cd`, recorded exports, and a `shlex.quote`-escaped argv sequence.

Cases I/J/K/L are strict original-CLI controls: they retain the old Vidur CLI shape and change the recorded GPU/CPU input paths and graph timing choice as shown by the launch records. The paired conditions are C=I, D=J, E=K, F=L.

## A_original_runtime_original_inputs

Recorded launch: [A_original_runtime_original_inputs.launch.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/A_original_runtime_original_inputs.launch.json).

```sh
cd /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/original_runtime
export PYTHONPATH=/home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/original_runtime
export WANDB_MODE=disabled
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export LOKY_MAX_CPU_COUNT=4
/home/turbo_ops/miniconda3/envs/sarathi/bin/python -m vidur.main --seed 36 --replica_config_model_name meta-llama/Llama-2-7b-hf --replica_config_device h100 --replica_config_network_device h100_dgx --replica_config_tensor_parallel_size 4 --replica_config_num_pipeline_stages 1 --replica_config_pd_node_ratio 1 --replica_config_memory_margin_fraction 0.2 --cluster_config_num_replicas 1 --global_scheduler_config_type round_robin --replica_scheduler_config_type vllm --vllm_scheduler_config_batch_size_cap 8 --vllm_scheduler_config_block_size 16 --vllm_scheduler_config_max_tokens_in_batch 4096 --request_generator_config_type trace_replay --trace_request_generator_config_trace_file /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/request_trace.csv --trace_request_generator_config_prefill_scale_factor 1.0 --trace_request_generator_config_decode_scale_factor 1.0 --trace_request_generator_config_time_scale_factor 1.0 --trace_request_generator_config_max_tokens 4096 --random_forrest_execution_time_predictor_config_backend vidur --random_forrest_execution_time_predictor_config_cpu_overhead_input_file /home/turbo_ops/changle/Files/vidur_cpu_overhead/cpu_overheads.csv --random_forrest_execution_time_predictor_config_prediction_max_prefill_chunk_size 4096 --random_forrest_execution_time_predictor_config_prediction_max_batch_size 8 --random_forrest_execution_time_predictor_config_prediction_max_tokens_per_request 4096 --random_forrest_execution_time_predictor_config_nccl_cpu_launch_overhead_ms 0 --random_forrest_execution_time_predictor_config_nccl_cpu_skew_overhead_per_device_ms 0.003 --no-random_forrest_execution_time_predictor_config_skip_cpu_overhead_modeling --metrics_config_keep_individual_batch_metrics --no-metrics_config_store_plots --no-metrics_config_enable_chrome_trace --metrics_config_cache_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/cache --metrics_config_output_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/A_original_runtime_original_inputs
```

## B_current_runtime_original_inputs

Recorded launch: [B_current_runtime_original_inputs.launch.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/B_current_runtime_original_inputs.launch.json).

```sh
cd /home/turbo_ops/changle/SimAI/vidur-alibabacloud
export PYTHONPATH=/home/turbo_ops/changle/SimAI/vidur-alibabacloud
export WANDB_MODE=disabled
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export LOKY_MAX_CPU_COUNT=4
/home/turbo_ops/miniconda3/envs/sarathi/bin/python -m vidur.main --seed 36 --replica_config_model_name meta-llama/Llama-2-7b-hf --replica_config_device h100 --replica_config_network_device h100_dgx --replica_config_tensor_parallel_size 4 --replica_config_num_pipeline_stages 1 --replica_config_pd_node_ratio 1 --replica_config_memory_margin_fraction 0.2 --cluster_config_num_replicas 1 --global_scheduler_config_type round_robin --replica_scheduler_config_type vllm --vllm_scheduler_config_batch_size_cap 8 --vllm_scheduler_config_block_size 16 --vllm_scheduler_config_max_tokens_in_batch 4096 --request_generator_config_type trace_replay --trace_request_generator_config_trace_file /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/request_trace.csv --trace_request_generator_config_prefill_scale_factor 1.0 --trace_request_generator_config_decode_scale_factor 1.0 --trace_request_generator_config_time_scale_factor 1.0 --trace_request_generator_config_max_tokens 4096 --random_forrest_execution_time_predictor_config_backend vidur --random_forrest_execution_time_predictor_config_cpu_overhead_input_file /home/turbo_ops/changle/Files/vidur_cpu_overhead/cpu_overheads.csv --random_forrest_execution_time_predictor_config_prediction_max_prefill_chunk_size 4096 --random_forrest_execution_time_predictor_config_prediction_max_batch_size 8 --random_forrest_execution_time_predictor_config_prediction_max_tokens_per_request 4096 --random_forrest_execution_time_predictor_config_nccl_cpu_launch_overhead_ms 0 --random_forrest_execution_time_predictor_config_nccl_cpu_skew_overhead_per_device_ms 0.003 --no-random_forrest_execution_time_predictor_config_skip_cpu_overhead_modeling --metrics_config_keep_individual_batch_metrics --no-metrics_config_store_plots --no-metrics_config_enable_chrome_trace --metrics_config_cache_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/cache --metrics_config_output_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/B_current_runtime_original_inputs
```

## C_native_gpu_old_cpu_no_graph

Recorded launch: [C_native_gpu_old_cpu_no_graph.launch.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/C_native_gpu_old_cpu_no_graph.launch.json).
Config: [C_native_gpu_old_cpu_no_graph.config.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/C_native_gpu_old_cpu_no_graph.config.json).

```sh
cd /home/turbo_ops/changle/SimAI/vidur-alibabacloud
export PYTHONPATH=/home/turbo_ops/changle/SimAI/vidur-alibabacloud
export WANDB_MODE=disabled
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export LOKY_MAX_CPU_COUNT=4
/home/turbo_ops/miniconda3/envs/sarathi/bin/python /home/turbo_ops/changle/SimAI/vidur-alibabacloud/scripts/run_vllm051_profiled_simulation.py --config /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/C_native_gpu_old_cpu_no_graph.config.json --mode replay --trace /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/request_trace.csv --output-dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/C_native_gpu_old_cpu_no_graph
```

## D_native_gpu_old_cpu_with_graph

Recorded launch: [D_native_gpu_old_cpu_with_graph.launch.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/D_native_gpu_old_cpu_with_graph.launch.json).
Config: [D_native_gpu_old_cpu_with_graph.config.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/D_native_gpu_old_cpu_with_graph.config.json).

```sh
cd /home/turbo_ops/changle/SimAI/vidur-alibabacloud
export PYTHONPATH=/home/turbo_ops/changle/SimAI/vidur-alibabacloud
export WANDB_MODE=disabled
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export LOKY_MAX_CPU_COUNT=4
/home/turbo_ops/miniconda3/envs/sarathi/bin/python /home/turbo_ops/changle/SimAI/vidur-alibabacloud/scripts/run_vllm051_profiled_simulation.py --config /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/D_native_gpu_old_cpu_with_graph.config.json --mode replay --trace /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/request_trace.csv --output-dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/D_native_gpu_old_cpu_with_graph
```

## E_native_gpu_new_cpu_no_graph

Recorded launch: [E_native_gpu_new_cpu_no_graph.launch.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/E_native_gpu_new_cpu_no_graph.launch.json).
Config: [E_native_gpu_new_cpu_no_graph.config.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/E_native_gpu_new_cpu_no_graph.config.json).

```sh
cd /home/turbo_ops/changle/SimAI/vidur-alibabacloud
export PYTHONPATH=/home/turbo_ops/changle/SimAI/vidur-alibabacloud
export WANDB_MODE=disabled
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export LOKY_MAX_CPU_COUNT=4
/home/turbo_ops/miniconda3/envs/sarathi/bin/python /home/turbo_ops/changle/SimAI/vidur-alibabacloud/scripts/run_vllm051_profiled_simulation.py --config /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/E_native_gpu_new_cpu_no_graph.config.json --mode replay --trace /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/request_trace.csv --output-dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/E_native_gpu_new_cpu_no_graph
```

## F_native_gpu_new_cpu_with_graph

Recorded launch: [F_native_gpu_new_cpu_with_graph.launch.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/F_native_gpu_new_cpu_with_graph.launch.json).
Config: [F_native_gpu_new_cpu_with_graph.config.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/F_native_gpu_new_cpu_with_graph.config.json).

```sh
cd /home/turbo_ops/changle/SimAI/vidur-alibabacloud
export PYTHONPATH=/home/turbo_ops/changle/SimAI/vidur-alibabacloud
export WANDB_MODE=disabled
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export LOKY_MAX_CPU_COUNT=4
/home/turbo_ops/miniconda3/envs/sarathi/bin/python /home/turbo_ops/changle/SimAI/vidur-alibabacloud/scripts/run_vllm051_profiled_simulation.py --config /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/F_native_gpu_new_cpu_with_graph.config.json --mode replay --trace /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/request_trace.csv --output-dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/F_native_gpu_new_cpu_with_graph
```

## G_original_tp2

Recorded launch: [G_original_tp2.launch.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/G_original_tp2.launch.json).

```sh
cd /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/original_runtime
export PYTHONPATH=/home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/original_runtime
export WANDB_MODE=disabled
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export LOKY_MAX_CPU_COUNT=4
/home/turbo_ops/miniconda3/envs/sarathi/bin/python -m vidur.main --seed 36 --replica_config_model_name meta-llama/Llama-2-7b-hf --replica_config_device h100 --replica_config_network_device h100_dgx --replica_config_tensor_parallel_size 2 --replica_config_num_pipeline_stages 1 --replica_config_pd_node_ratio 1 --replica_config_memory_margin_fraction 0.2 --cluster_config_num_replicas 1 --global_scheduler_config_type round_robin --replica_scheduler_config_type vllm --vllm_scheduler_config_batch_size_cap 8 --vllm_scheduler_config_block_size 16 --vllm_scheduler_config_max_tokens_in_batch 4096 --request_generator_config_type trace_replay --trace_request_generator_config_trace_file /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/request_trace.csv --trace_request_generator_config_prefill_scale_factor 1.0 --trace_request_generator_config_decode_scale_factor 1.0 --trace_request_generator_config_time_scale_factor 1.0 --trace_request_generator_config_max_tokens 4096 --random_forrest_execution_time_predictor_config_backend vidur --random_forrest_execution_time_predictor_config_cpu_overhead_input_file /home/turbo_ops/changle/Files/vidur_cpu_overhead/cpu_overheads.csv --random_forrest_execution_time_predictor_config_prediction_max_prefill_chunk_size 4096 --random_forrest_execution_time_predictor_config_prediction_max_batch_size 8 --random_forrest_execution_time_predictor_config_prediction_max_tokens_per_request 4096 --random_forrest_execution_time_predictor_config_nccl_cpu_launch_overhead_ms 0 --random_forrest_execution_time_predictor_config_nccl_cpu_skew_overhead_per_device_ms 0.003 --no-random_forrest_execution_time_predictor_config_skip_cpu_overhead_modeling --metrics_config_keep_individual_batch_metrics --no-metrics_config_store_plots --no-metrics_config_enable_chrome_trace --metrics_config_cache_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/cache --metrics_config_output_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/G_original_tp2
```

## H_current_tp2

Recorded launch: [H_current_tp2.launch.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/H_current_tp2.launch.json).

```sh
cd /home/turbo_ops/changle/SimAI/vidur-alibabacloud
export PYTHONPATH=/home/turbo_ops/changle/SimAI/vidur-alibabacloud
export WANDB_MODE=disabled
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export LOKY_MAX_CPU_COUNT=4
/home/turbo_ops/miniconda3/envs/sarathi/bin/python -m vidur.main --seed 36 --replica_config_model_name meta-llama/Llama-2-7b-hf --replica_config_device h100 --replica_config_network_device h100_dgx --replica_config_tensor_parallel_size 2 --replica_config_num_pipeline_stages 1 --replica_config_pd_node_ratio 1 --replica_config_memory_margin_fraction 0.2 --cluster_config_num_replicas 1 --global_scheduler_config_type round_robin --replica_scheduler_config_type vllm --vllm_scheduler_config_batch_size_cap 8 --vllm_scheduler_config_block_size 16 --vllm_scheduler_config_max_tokens_in_batch 4096 --request_generator_config_type trace_replay --trace_request_generator_config_trace_file /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/request_trace.csv --trace_request_generator_config_prefill_scale_factor 1.0 --trace_request_generator_config_decode_scale_factor 1.0 --trace_request_generator_config_time_scale_factor 1.0 --trace_request_generator_config_max_tokens 4096 --random_forrest_execution_time_predictor_config_backend vidur --random_forrest_execution_time_predictor_config_cpu_overhead_input_file /home/turbo_ops/changle/Files/vidur_cpu_overhead/cpu_overheads.csv --random_forrest_execution_time_predictor_config_prediction_max_prefill_chunk_size 4096 --random_forrest_execution_time_predictor_config_prediction_max_batch_size 8 --random_forrest_execution_time_predictor_config_prediction_max_tokens_per_request 4096 --random_forrest_execution_time_predictor_config_nccl_cpu_launch_overhead_ms 0 --random_forrest_execution_time_predictor_config_nccl_cpu_skew_overhead_per_device_ms 0.003 --no-random_forrest_execution_time_predictor_config_skip_cpu_overhead_modeling --metrics_config_keep_individual_batch_metrics --no-metrics_config_store_plots --no-metrics_config_enable_chrome_trace --metrics_config_cache_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/cache --metrics_config_output_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/H_current_tp2
```

## I_current_old_config_new_gpu

Recorded launch: [I_current_old_config_new_gpu.launch.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/I_current_old_config_new_gpu.launch.json).

```sh
cd /home/turbo_ops/changle/SimAI/vidur-alibabacloud
export PYTHONPATH=/home/turbo_ops/changle/SimAI/vidur-alibabacloud
export WANDB_MODE=disabled
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export LOKY_MAX_CPU_COUNT=4
/home/turbo_ops/miniconda3/envs/sarathi/bin/python -m vidur.main --seed 36 --replica_config_model_name meta-llama/Llama-2-7b-hf --replica_config_device h100 --replica_config_network_device h100_dgx --replica_config_tensor_parallel_size 4 --replica_config_num_pipeline_stages 1 --replica_config_pd_node_ratio 1 --replica_config_memory_margin_fraction 0.2 --cluster_config_num_replicas 1 --global_scheduler_config_type round_robin --replica_scheduler_config_type vllm --vllm_scheduler_config_batch_size_cap 8 --vllm_scheduler_config_block_size 16 --vllm_scheduler_config_max_tokens_in_batch 4096 --request_generator_config_type trace_replay --trace_request_generator_config_trace_file /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/request_trace.csv --trace_request_generator_config_prefill_scale_factor 1.0 --trace_request_generator_config_decode_scale_factor 1.0 --trace_request_generator_config_time_scale_factor 1.0 --trace_request_generator_config_max_tokens 4096 --random_forrest_execution_time_predictor_config_backend vidur --random_forrest_execution_time_predictor_config_cpu_overhead_input_file /home/turbo_ops/changle/Files/vidur_cpu_overhead/cpu_overheads.csv --random_forrest_execution_time_predictor_config_prediction_max_prefill_chunk_size 4096 --random_forrest_execution_time_predictor_config_prediction_max_batch_size 8 --random_forrest_execution_time_predictor_config_prediction_max_tokens_per_request 4096 --random_forrest_execution_time_predictor_config_nccl_cpu_launch_overhead_ms 0 --random_forrest_execution_time_predictor_config_nccl_cpu_skew_overhead_per_device_ms 0.003 --no-random_forrest_execution_time_predictor_config_skip_cpu_overhead_modeling --metrics_config_keep_individual_batch_metrics --no-metrics_config_store_plots --no-metrics_config_enable_chrome_trace --metrics_config_cache_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/cache --metrics_config_output_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/I_current_old_config_new_gpu --random_forrest_execution_time_predictor_config_compute_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/mlp_tp4_native.csv --random_forrest_execution_time_predictor_config_attention_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/attention_tp4_native.csv --random_forrest_execution_time_predictor_config_all_reduce_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/collectives_tp4_native.csv
```

## J_current_old_config_new_gpu_graph

Recorded launch: [J_current_old_config_new_gpu_graph.launch.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/J_current_old_config_new_gpu_graph.launch.json).

```sh
cd /home/turbo_ops/changle/SimAI/vidur-alibabacloud
export PYTHONPATH=/home/turbo_ops/changle/SimAI/vidur-alibabacloud
export WANDB_MODE=disabled
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export LOKY_MAX_CPU_COUNT=4
/home/turbo_ops/miniconda3/envs/sarathi/bin/python -m vidur.main --seed 36 --replica_config_model_name meta-llama/Llama-2-7b-hf --replica_config_device h100 --replica_config_network_device h100_dgx --replica_config_tensor_parallel_size 4 --replica_config_num_pipeline_stages 1 --replica_config_pd_node_ratio 1 --replica_config_memory_margin_fraction 0.2 --cluster_config_num_replicas 1 --global_scheduler_config_type round_robin --replica_scheduler_config_type vllm --vllm_scheduler_config_batch_size_cap 8 --vllm_scheduler_config_block_size 16 --vllm_scheduler_config_max_tokens_in_batch 4096 --request_generator_config_type trace_replay --trace_request_generator_config_trace_file /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/request_trace.csv --trace_request_generator_config_prefill_scale_factor 1.0 --trace_request_generator_config_decode_scale_factor 1.0 --trace_request_generator_config_time_scale_factor 1.0 --trace_request_generator_config_max_tokens 4096 --random_forrest_execution_time_predictor_config_backend vidur --random_forrest_execution_time_predictor_config_cpu_overhead_input_file /home/turbo_ops/changle/Files/vidur_cpu_overhead/cpu_overheads.csv --random_forrest_execution_time_predictor_config_prediction_max_prefill_chunk_size 4096 --random_forrest_execution_time_predictor_config_prediction_max_batch_size 8 --random_forrest_execution_time_predictor_config_prediction_max_tokens_per_request 4096 --random_forrest_execution_time_predictor_config_nccl_cpu_launch_overhead_ms 0 --random_forrest_execution_time_predictor_config_nccl_cpu_skew_overhead_per_device_ms 0.003 --no-random_forrest_execution_time_predictor_config_skip_cpu_overhead_modeling --metrics_config_keep_individual_batch_metrics --no-metrics_config_store_plots --no-metrics_config_enable_chrome_trace --metrics_config_cache_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/cache --metrics_config_output_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/J_current_old_config_new_gpu_graph --random_forrest_execution_time_predictor_config_compute_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/mlp_tp4_native.csv --random_forrest_execution_time_predictor_config_attention_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/attention_tp4_native.csv --random_forrest_execution_time_predictor_config_all_reduce_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/collectives_tp4_native.csv --random_forrest_execution_time_predictor_config_decoder_graph_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/decoder_tp4_native.csv
```

## K_current_old_config_new_gpu_new_cpu

Recorded launch: [K_current_old_config_new_gpu_new_cpu.launch.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/K_current_old_config_new_gpu_new_cpu.launch.json).

```sh
cd /home/turbo_ops/changle/SimAI/vidur-alibabacloud
export PYTHONPATH=/home/turbo_ops/changle/SimAI/vidur-alibabacloud
export WANDB_MODE=disabled
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export LOKY_MAX_CPU_COUNT=4
/home/turbo_ops/miniconda3/envs/sarathi/bin/python -m vidur.main --seed 36 --replica_config_model_name meta-llama/Llama-2-7b-hf --replica_config_device h100 --replica_config_network_device h100_dgx --replica_config_tensor_parallel_size 4 --replica_config_num_pipeline_stages 1 --replica_config_pd_node_ratio 1 --replica_config_memory_margin_fraction 0.2 --cluster_config_num_replicas 1 --global_scheduler_config_type round_robin --replica_scheduler_config_type vllm --vllm_scheduler_config_batch_size_cap 8 --vllm_scheduler_config_block_size 16 --vllm_scheduler_config_max_tokens_in_batch 4096 --request_generator_config_type trace_replay --trace_request_generator_config_trace_file /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/request_trace.csv --trace_request_generator_config_prefill_scale_factor 1.0 --trace_request_generator_config_decode_scale_factor 1.0 --trace_request_generator_config_time_scale_factor 1.0 --trace_request_generator_config_max_tokens 4096 --random_forrest_execution_time_predictor_config_backend vidur --random_forrest_execution_time_predictor_config_cpu_overhead_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/cpu_tp4pp1_coverage.csv --random_forrest_execution_time_predictor_config_prediction_max_prefill_chunk_size 4096 --random_forrest_execution_time_predictor_config_prediction_max_batch_size 8 --random_forrest_execution_time_predictor_config_prediction_max_tokens_per_request 4096 --random_forrest_execution_time_predictor_config_nccl_cpu_launch_overhead_ms 0 --random_forrest_execution_time_predictor_config_nccl_cpu_skew_overhead_per_device_ms 0.003 --no-random_forrest_execution_time_predictor_config_skip_cpu_overhead_modeling --metrics_config_keep_individual_batch_metrics --no-metrics_config_store_plots --no-metrics_config_enable_chrome_trace --metrics_config_cache_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/cache --metrics_config_output_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/K_current_old_config_new_gpu_new_cpu --random_forrest_execution_time_predictor_config_compute_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/mlp_tp4_native.csv --random_forrest_execution_time_predictor_config_attention_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/attention_tp4_native.csv --random_forrest_execution_time_predictor_config_all_reduce_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/collectives_tp4_native.csv --random_forrest_execution_time_predictor_config_execution_loop_mode http_serving_spaced_diagnostic
```

## L_current_old_config_all_new

Recorded launch: [L_current_old_config_all_new.launch.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/legacy_regression/L_current_old_config_all_new.launch.json).

```sh
cd /home/turbo_ops/changle/SimAI/vidur-alibabacloud
export PYTHONPATH=/home/turbo_ops/changle/SimAI/vidur-alibabacloud
export WANDB_MODE=disabled
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export LOKY_MAX_CPU_COUNT=4
/home/turbo_ops/miniconda3/envs/sarathi/bin/python -m vidur.main --seed 36 --replica_config_model_name meta-llama/Llama-2-7b-hf --replica_config_device h100 --replica_config_network_device h100_dgx --replica_config_tensor_parallel_size 4 --replica_config_num_pipeline_stages 1 --replica_config_pd_node_ratio 1 --replica_config_memory_margin_fraction 0.2 --cluster_config_num_replicas 1 --global_scheduler_config_type round_robin --replica_scheduler_config_type vllm --vllm_scheduler_config_batch_size_cap 8 --vllm_scheduler_config_block_size 16 --vllm_scheduler_config_max_tokens_in_batch 4096 --request_generator_config_type trace_replay --trace_request_generator_config_trace_file /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/request_trace.csv --trace_request_generator_config_prefill_scale_factor 1.0 --trace_request_generator_config_decode_scale_factor 1.0 --trace_request_generator_config_time_scale_factor 1.0 --trace_request_generator_config_max_tokens 4096 --random_forrest_execution_time_predictor_config_backend vidur --random_forrest_execution_time_predictor_config_cpu_overhead_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/cpu_tp4pp1_coverage.csv --random_forrest_execution_time_predictor_config_prediction_max_prefill_chunk_size 4096 --random_forrest_execution_time_predictor_config_prediction_max_batch_size 8 --random_forrest_execution_time_predictor_config_prediction_max_tokens_per_request 4096 --random_forrest_execution_time_predictor_config_nccl_cpu_launch_overhead_ms 0 --random_forrest_execution_time_predictor_config_nccl_cpu_skew_overhead_per_device_ms 0.003 --no-random_forrest_execution_time_predictor_config_skip_cpu_overhead_modeling --metrics_config_keep_individual_batch_metrics --no-metrics_config_store_plots --no-metrics_config_enable_chrome_trace --metrics_config_cache_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/cache --metrics_config_output_dir /home/turbo_ops/changle/Files/analysis/tp_legacy_regression_20261002/L_current_old_config_all_new --random_forrest_execution_time_predictor_config_compute_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/mlp_tp4_native.csv --random_forrest_execution_time_predictor_config_attention_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/attention_tp4_native.csv --random_forrest_execution_time_predictor_config_all_reduce_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/collectives_tp4_native.csv --random_forrest_execution_time_predictor_config_execution_loop_mode http_serving_spaced_diagnostic --random_forrest_execution_time_predictor_config_decoder_graph_input_file /home/turbo_ops/changle/Files/analysis/tp4_mixed_pp_20261002/decoder_tp4_native.csv
```

## Verification context

The archived top-level state files report A–F, G–H, and I–L complete; the independent three-request arithmetic and component reconciliation are in [tp_original_path_regression_audit.md](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_audit.md). The evidence ZIP member hashes and extraction checks are recorded in [tp_original_path_regression_evidence_validation.json](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence_validation.json).
