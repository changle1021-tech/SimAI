这轮查清了上次 TP4 结果明显下降的来源：我后续测试更换了 GPU、注意力和通信采样表，并启用了新的服务步骤与整块解码计时。原命令使用原表时，PP 修改前后的代码没有出现同样的约31%下降。我上次没有保留原配置做并排回归对照，因此把新路径的失败泛称为“纯TP不准确”，这个归因不够严谨。

本轮没有修改产品源码，没有补采 GPU 数据，也没有新增补偿参数。用第一次 PP 改动前的真实备份建立隔离副本，正式仓库的源码、原输入表保持不变。输入512、输出50，三个请求按同一份保存轨迹约0、10、20秒到达；TP4/PP1与TP2/PP1各比较旧、新代码。模拟结果是这条稀疏轨迹的因果对照，不能代表高并发或所有模型。

TP4 的实测参照沿用上轮10轮×3个请求的总体均值：E2E429.564ms，客户端TTFT25.205ms，TPOT8.252ms。用户提供的 FP16、Ray、关闭自定义all-reduce、4096上下文、8并发上限、4096批token、block16、GPU利用率0.8及图捕获上限4096均与上轮服务相同。用户命令用GPU0–3，上轮实测用GPU2–5；没有历史准确测试的原始结果，因此不把这次参照视为完整复现历史测试。

| TP4/PP1路径 | E2E ms | 内部首步 ms | TPOT ms | 对最新实测E2E误差 |
| --- | ---: | ---: | ---: | ---: |
| A：修改前代码＋原表 | 376.027 | 11.058 | 7.448 | −12.46% |
| B：当前代码＋原表 | 380.303 | 11.199 | 7.533 | −11.47% |
| I：B仅换新GPU/注意力/通信表 | 279.616 | 10.526 | 5.492 | −34.91% |
| J：I再启用整块解码 | 269.957 | 10.526 | 5.295 | −37.16% |
| K：I换新CPU服务表、启用服务步骤计时 | 304.740 | 25.518 | 5.698 | −29.06% |
| L：新GPU表＋新CPU服务表＋整块解码 | 295.081 | 25.518 | 5.501 | −31.31% |

I/J/K/L直接复制B的命令，仅替换对应文件与计时选项。早先C/D/E/F通过保存配置恢复，另有请求生成器默认种子、训练线程数、rank放置和图容量的显式配置差异；严格对照I/J/K/L与C/D/E/F数值完全相同。所有路径保留原来全局seed36、原有NCCL CPU参数0与0.003，不使用它们重新拟合结果。源码核查也确认 trace_replay 直接读取保存轨迹，不使用请求生成器的随机种子。

内部首步是模拟器的预填充完成时间，客户端TTFT还涉及实际服务输出和客户端接收，两者观察终点尚未完整对齐。表中TPOT按(E2E−首步)/49计算，因此TTFT/TPOT是观察终点不同的对照。B、L均没有达到与最新实测E2E总体均值相差±10%的要求。旧路径也有差距，不能据这轮结果宣称“恢复原表即可修好”。

原表下的纯TP对照如下；表中变化是模拟输出变化，不是对实测的准确率。

| 模式 | 修改前E2E ms | 当前E2E ms | 模拟输出变化 | 修改前/当前内部首步 ms | 修改前/当前TPOT ms |
| --- | ---: | ---: | ---: | --- | --- |
| TP2/PP1 | 371.682 | 377.663 | +1.61% | 13.188 / 13.384 | 7.316 / 7.434 |
| TP4/PP1 | 376.027 | 380.303 | +1.14% | 11.058 / 11.199 | 7.448 / 7.533 |

本轮没有TP2/PP1多轮原生实测，只比较代码变化；TP2/PP2的实测不能替代TP2/PP1。

代码确实改到了纯TP共用的部分。原表下A到B增加4.276ms：新计入旋转位置计算3.787ms、模型开头计算0.278ms，其余重新训练预测后的数值变化0.211ms。原CPU表中TP2与TP4各8行原始字段全部保留，没有被PP采样覆盖。旧表的TP通信公式也仍保留。因此，这些共有代码变化解释的是小幅增加，而不是新版TP4结果的大幅缩短。

上次新路径的下降集中在生成步骤。B到I，每步总时间从7.533降到5.492ms，减少2.041ms；其中通信减少1.762ms，其他模型计算减少0.280ms，CPU增加0.000847ms。49步累计，再加首步变化，整条请求减少100.687ms。启用整块解码另减少9.659ms；换新CPU服务路径则增加25.124ms。三者相加解释B到L减少85.222ms，账目和请求结果吻合。

这里有两个同时发生的变化：原表查表时把一枚输出按8枚计算，新表按实际图执行的一枚计算；原通信路径包含GPU通信预测和原参数给出的等待估算，新采样路径只采用独立采得的GPU通信，整块解码则已把内部通信合并进去。原命令已有的0.003×TP^1.25这一项，在TP4的49步中合计53.220ms，切换新路径后不再计入。这只是解释现有账目的变化，不是证明真实等待恰好为53.220ms，更不是建议把该估算加回来。GPU表本身的差异与一枚/八枚映射尚未分别隔离。

需要补齐的是各张卡之间的实际等待关系。现有服务步骤采样和模拟只记录每个PP组带头卡的准备；同一TP组里其他卡何时准备好，没有独立进入推演。四张卡共同工作时，有人在交流前晚到，其他人需要等它；独立采样采用连续、协调的提交，不能自动反映实际服务的错开。已有插桩显示TP4在512输入下各卡前向提交的平均时间跨度1.506ms，服务GPU前向区间比独立解码块长，支持这条调查方向。但两种区间包含的工作不同，且插桩会影响时序，尚不能证明全部134.483ms实测差距都由它造成。

通用修复应当记录每张卡收到工作、准备输入、提交计算、进入交流、输出汇集和返回的先后关系，再根据这些步骤推算完成时刻。每次交流要等参与的卡实际到达；可同时执行的工作同时计时。等待应从这些依赖关系产生，不从请求误差中补一个数。GPU工作、通信和CPU步骤各采一次，避免整块解码已经包含通信时重复计算。

更换模型时依据其实际层结构、首尾计算和切分方式建立步骤，并采相应计算；更换TP/PP时依据真实分组与各卡执行顺序建立等待关系。这种方法适合通用模拟器，但当前实现的逐卡准备与等待部分仍不完整，不能宣称新TP4路径已修复，也不能宣称其他模型、高并发或跨节点已验证。这轮没有跨节点测试。

影响纯TP的主要代码位置如下。这些是此前PP修复中的修改，本轮新增产品源码修改为零。

| 位置 | 修改内容 | 原表路径是否生效 |
| --- | --- | --- |
| [旋转位置计算](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/current_source/vidur/execution_time_predictor/sklearn_execution_time_predictor.py:1643) | 原来恒为0，改为计入采样到的计算 | 是 |
| [模型首尾计算](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/current_source/vidur/execution_time_predictor/sklearn_execution_time_predictor.py:1549) | 加入embedding，按数据覆盖计入首尾归一化 | 是；原表只覆盖embedding |
| [实际计算量](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/current_source/vidur/execution_time_predictor/sklearn_execution_time_predictor.py:1537) | 新注意力表按真实CUDA图批量查询，单请求为1 | 新表启用 |
| [TP通信](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/current_source/vidur/execution_time_predictor/sklearn_execution_time_predictor.py:1602) | 原表保留原公式；新通信表采用独立GPU采样，整块解码中的通信避免重复计入 | 根据输入表和解码选项切换 |
| [CPU表筛选与服务步骤](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/current_source/vidur/execution_time_predictor/sklearn_execution_time_predictor.py:335) | 按模型、TP、PP等匹配；schema8启用命名步骤 | 保留原TP2/TP4行；新表启用新步骤 |
| [各阶段准备与返回](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/current_source/vidur/execution_time_predictor/sklearn_execution_time_predictor.py:1459) | 用每个阶段主卡的准备、通知、返回推算时间 | schema8启用，缺少TP组内各卡的独立就绪时间 |
| [整块解码](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/current_source/vidur/execution_time_predictor/sklearn_execution_time_predictor.py:1528) | 用32层GPU解码块替代逐项相加 | 显式配置decoder表才启用 |
| [阶段耗时合计](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/current_source/vidur/entities/execution_time.py:1306) | 将整块解码、GPU通信和边界按覆盖关系合计 | 与以上分支一致 |
| [共有阶段调用](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/current_source/vidur/execution_time_predictor/base_execution_time_predictor.py:68) | 分阶段放入CPU工作、GPU工作与服务步骤 | PP1也使用此调用入口 |
| [预测缓存标识](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence/current_source/vidur/execution_time_predictor/sklearn_execution_time_predictor.py:532) | 按输入、目标、布局等区分缓存 | 是，可能触发重新训练 |

全部此前源码修改见 [27个运行文件清单](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/single_node_pp_code_changes.md)，分支细节见 [原表与新表的源码路径](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_source_branches.md)。

本轮176份Vidur源码、5份原输入均与开始时一致；再次核对上轮全项目222份源码和18份冻结新采样输入，也全部一致。正式请求与采样数据没有为这次对照调整。本轮12组模拟共36个重放请求；实测参照为之前保存的30个TP4请求，没有新增实测请求。

完整命令见 [原路径回归命令](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_commands.md)。恢复来源、逐请求结果、逐步骤账目、原/新输入表与源文件及1036个成员逐字节哈希校验见 [证据包](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_evidence.zip)。独立核算见 [审计记录](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/tp_original_path_regression_audit.json)。此前TP4/混合模式80组测试命令仍见 [原实验命令](/mnt/c/users/changle/documents/codex/2026-09-30/mu-q-2/outputs/llama2_tp4_mixed_test_commands.md)。
