# 单节点 PP 源码差异清点

范围依据 `work/single_node_final_export/evidence/single_node_q9_deployment.json` 中 `files` 字段的 27 个 runtime 文件。存在 `backup/repo/<相对路径>` 的列为“修改”，不存在的列为“新增”；新增文件补丁以 `/dev/null` 为旧文件。行数为统一 diff 中增删的内容行数，不计 diff 头。主要变更函数按 Python AST 符号差异清点，无法归属函数的模块级变化会单独标注。

| # | 仓库相对路径 | 类型 | 增加 | 删除 | 主要变更函数 / 顶层符号 |
|---:|---|---|---:|---:|---|
| 1 | `vidur/profiling/cpu_overhead/vllm_051_pp_cpu_profile.py` | 修改 | 171 | 38 | ~run_batch, ~run, ~schedule, ~profile, ~execute, ~process_outputs, +timed_step, +pinned_add_request, +mark_idle, +consume |
| 2 | `vidur/profiling/cpu_overhead/vllm_051_http_profile_server.py` | 新增 | 160 | 0 | 顶层: mark_idle, DiagnosticExecutor, schedule, process, step, persist, start_profile, collect_profile, audit_observations, add_request, app_init |
| 3 | `vidur/profiling/cpu_overhead/pp_profile_contract.py` | 修改 | 43 | 5 | ~aggregate_step, +bind_worker_keys |
| 4 | `vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py` | 修改 | 15 | 3 | ~_parse_args, ~main |
| 5 | `vidur/profiling/cpu_overhead/vllm_051_profile_common.py` | 新增 | 246 | 0 | 顶层: csv_schema, resolve_tp_sizes, read_reference, check_metadata, align_reference_rows, check_vllm_version, init_tp, close_tp, gpu_times, put_stats, write_csv, run_all_tp |
| 6 | `vidur/profiling/cpu_overhead/profile_native_collectives.py` | 新增 | 73 | 0 | 顶层: Rank, main |
| 7 | `vidur/profiling/cpu_overhead/eager_dispatch_trace.py` | 新增 | 96 | 0 | 顶层: install_llama_dispatch_trace, dispatch_program, mean_program |
| 8 | `vidur/profiling/cpu_overhead/vllm_051_attention_profile.py` | 新增 | 410 | 0 | 顶层: prefill_grid, kv_grid, batch_grid, cases, valid_case, reference_defaults, graph_batch_size, execution_fields, parser, profile_case, worker, main |
| 9 | `vidur/profiling/cpu_overhead/vllm_051_http_cpu_profile.py` | 新增 | 53 | 0 | 顶层: run |
| 10 | `vidur/profiling/cpu_overhead/dispatch_profile_contract.py` | 新增 | 126 | 0 | 顶层: trace_driver_tasks, task_dispatch_intervals, pipeline_protocol_primitives |
| 11 | `vidur/profiling/cpu_overhead/vllm_051_pp_worker.py` | 修改 | 130 | 11 | ~forward_wrap, ~pp_profile_set_enabled, ~execute_model, ~cpu_wrap, ~timed, ~pp_profile_get_records, ~Worker, +pp_profile_environment, +pp_profile_reserve_events, +pp_profile_trace_begin |
| 12 | `vidur/profiling/cpu_overhead/vllm_051_mlp_profile.py` | 新增 | 228 | 0 | 顶层: vidur_token_grid, token_cases, execution_fields, parser, worker, main |
| 13 | `vidur/profiling/cpu_overhead/vllm_051_http_profile_client.py` | 新增 | 81 | 0 | 顶层: main |
| 14 | `vidur/profiling/cpu_overhead/http_profile_arguments.py` | 新增 | 69 | 0 | 顶层: server_arguments, client_arguments |
| 15 | `vidur/profiling/cpu_overhead/native_attention_geometry.py` | 新增 | 11 | 0 | 顶层: local_attention_heads |
| 16 | `vidur/entities/execution_time.py` | 修改 | 27 | 2 | ~__init__, ~_get_cpu_overhead, ~ExecutionTime, ~model_time |
| 17 | `vidur/entities/replica.py` | 修改 | 2 | 4 | ~__init__, ~Replica |
| 18 | `vidur/utils/runtime_layout.py` | 新增 | 41 | 0 | 顶层: graph_batch_size, canonical_rank_nodes, configured_rank_nodes, pipeline_layer_bounds |
| 19 | `vidur/utils/param_counter.py` | 修改 | 9 | 7 | ~__init__, ~get_num_parameters_per_device, ~ParamCounter |
| 20 | `vidur/utils/eager_dispatch_program.py` | 新增 | 45 | 0 | 顶层: replay_program, interpolate_program |
| 21 | `vidur/utils/decoder_graph_profile.py` | 新增 | 63 | 0 | 顶层: DecoderGraphProfile |
| 22 | `vidur/utils/native_collective_profile.py` | 新增 | 24 | 0 | 顶层: NativeCollectiveProfile |
| 23 | `vidur/config/config.py` | 修改 | 24 | 0 | ~ReplicaConfig, ~BaseExecutionTimePredictorConfig |
| 24 | `vidur/execution_time_predictor/sklearn_execution_time_predictor.py` | 修改 | 420 | 63 | ~_get_mlp_layer_down_proj_execution_time, ~_get_pipeline_parallel_communication_time, ~_get_attention_layer_pre_proj_execution_time, ~_train_compute_models, ~__init__, ~_get_add_layer_act_execution_time, ~_get_attention_layer_post_proj_execution_time, ~_get_attn_norm_layer_act_execution_time, ~_get_attention_prefill_execution_time, ~SklearnExecutionTimePredictor |
| 25 | `vidur/execution_time_predictor/base_execution_time_predictor.py` | 修改 | 65 | 23 | ~_get_pipeline_parallel_communication_time, ~__init__, ~get_execution_time, ~_get_tensor_parallel_communication_time, ~BaseExecutionTimePredictor, +_get_decoder_graph_execution_time, +_get_graph_input_staging_time, +_get_model_boundary_time, +_get_engine_bookkeeping_time, +_get_eager_forward_execution_time |
| 26 | `vidur/events/replica_stage_schedule_event.py` | 修改 | 1 | 1 | ~handle_event, ~ReplicaStageScheduleEvent |
| 27 | `vidur/scheduler/replica_stage_scheduler/replica_stage_schduler.py` | 修改 | 2 | 1 | ~ReplicaStageScheduler, ~on_schedule |

## 额外文件计数

- `repo/scripts/`：2 个工具：`scripts/profile_native_decoder_graph_vllm051.py`, `scripts/run_vllm051_profiled_simulation.py`
- `repo/tests/`：7 个测试文件：`tests/test_collectives_csv_schema.py`, `tests/test_dispatch_profile_contract.py`, `tests/test_eager_dispatch_program.py`, `tests/test_pp_cpu_profile.py`, `tests/test_pp_profile_contract.py`, `tests/test_runtime_layout_fidelity.py`, `tests/test_send_recv_profiling.py`
- `repo/configs/`：4 个配置文件（以实际目录递归计数）。
- `repo/data/`：11 个数据文件（以实际目录递归计数）。
- 以上四项按最终导出 repo 目录实数；除 27 个 runtime 文件外，不根据 backup 是否存在推断这些文件的旧版状态。

逐文件 unified diff 见 [`single_node_pp_code_changes.patch`](single_node_pp_code_changes.patch)。

补丁已通过 `git apply --numstat`、`git apply --check`，并在临时备份副本实际应用；27 个结果文件与最终部署源码逐字节一致，保留原始 CRLF/LF。验证记录见 `single_node_pp_patch_verification.json`。
