import json,os,subprocess,shutil,time,hashlib
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');S=R/'staging';P=Path('/home/turbo_ops/changle/SimAI/vidur-alibabacloud');O=R/'overlay'
s=dict(pid=os.getpid(),phase='copying',started_at_epoch=time.time())
def save():(R/'overlay_state.json').write_text(json.dumps(s))
save()
try:
 if O.exists():raise RuntimeError('Overlay already exists; inspect before replacing')
 O.mkdir();shutil.copytree(P/'vidur',O/'vidur');shutil.copytree(P/'tests',O/'tests')
 for base in ['vidur','tests','scripts']:
  for f in (S/base).rglob('*.py'):
   target=O/f.relative_to(S);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
 s['phase']='testing';save()
 env=os.environ.copy();env['PYTHONPATH']=str(O)
 with (R/'overlay_tests.log').open('w') as f:
  subprocess.run(['/home/turbo_ops/miniconda3/envs/sarathi/bin/python','-m','unittest','discover','-s',str(O/'tests'),'-p','test_*.py','-v'],cwd=P,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 s['phase']='complete';save()
except Exception as e:s.update(phase='failed',error=repr(e));save();raise
