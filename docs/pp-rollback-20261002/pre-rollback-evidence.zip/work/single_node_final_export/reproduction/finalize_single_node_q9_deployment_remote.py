import csv,json,hashlib,os,subprocess,time
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
P=Path('/home/turbo_ops/changle/SimAI/vidur-alibabacloud');S=R/'staging'
CPU=Path('/home/turbo_ops/changle/Files/vidur_cpu_overhead');PY='/home/turbo_ops/miniconda3/envs/sarathi/bin/python'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
state=json.loads((R/'single_node_corrected_q9_state.json').read_text())
if state['phase']!='complete' or not state['mean_e2e_pass']:raise RuntimeError('Accuracy gate failed')
for f in (S/'vidur').rglob('*.py'):
 if sha(f)!=sha(P/f.relative_to(S)):raise RuntimeError('Installed runtime differs from tested candidate')
kit=CPU/'single_node_pp_20261001'
for f in (S/'vidur/profiling/cpu_overhead').glob('*.py'):
 if sha(f)!=sha(kit/f.name):raise RuntimeError('Installed profiling toolkit differs')
if sha(CPU/'vllm_051_cpu_overhead.py')!=sha(R/'cpu_profile_entrypoint_q9.py'):raise RuntimeError('CPU entrypoint differs')
env=os.environ.copy();env.update(PYTHONPATH=str(P),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
result=dict(phase='verifying',pid=os.getpid(),started_at=time.time(),backup=str(R/'single_node_q9_deploy_backup'),mean_e2e_success_threshold_pct=10,verification='All four public configurations against ten preserved native rounds each. No primitive cost adjustments.',configurations=[],files=[])
output=R/'single_node_q9_deployment.json'
if output.exists():raise FileExistsError('Keep previous successful deployment manifest')
def save():output.write_text(json.dumps(result,indent=2))
save()
try:
 for item in state['completed']:
  a=item['arguments'];name=a['label'].replace('q9_corrected_','').replace('_program','')+'.json'
  conf=P/'configs/vllm051_single_node_pp'/name;c=json.loads(conf.read_text())
  for key in ['compute_input_file','attention_input_file','all_reduce_input_file','decoder_graph_input_file','cpu_overhead_input_file']:
   target=Path(c['execution_time_predictor_config'][key]);original=R/target.name
   if sha(target)!=sha(original):raise RuntimeError('Physical profile changed: '+str(target))
  values=[];rounds=[]
  for index in range(10):
   target=R/(a['label']+'_deployed_final_'+str(index))
   with (R/(target.name+'.log')).open('x') as log:
    subprocess.run([PY,str(P/'scripts/run_vllm051_profiled_simulation.py'),'--config',str(conf),'--mode','replay','--trace',str(R/(a['case_prefix']+'_'+str(index)+'/'+ 'arrival_trace.csv')),'--output-dir',str(target)],cwd=P,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
   metrics=Path((target/'run_path.txt').read_text())/'request_metrics.csv'
   measured=[float(r['request_e2e_time'])*1000 for r in csv.DictReader(metrics.open())]
   if len(measured)!=3:raise RuntimeError('Missing deployed simulation requests')
   values+=measured;prediction=sum(measured)/len(measured);actual=item['rounds'][index]['actual_e2e_mean_ms']
   rounds.append(dict(round=index,actual_e2e_mean_ms=actual,predicted_e2e_mean_ms=prediction,error_pct=100*(prediction/actual-1)))
  prediction=sum(values)/len(values);actual=item['actual_mean_ms'];error=100*(prediction/actual-1)
  if abs(error)>10:raise RuntimeError('Public configuration fails E2E requirement: '+name)
  result['configurations'].append(dict(config=str(conf),model=a['model'],tp=a['tp'],pp=a['pp'],requests=30,rounds=rounds,actual_mean_ms=actual,predicted_mean_ms=prediction,signed_error_pct=error,change_from_staged_prediction_ms=prediction-item['predicted_mean_ms']))
  save();print('PUBLIC_GATE',name,error,flush=True)
 with (R/'single_node_q9_cpu_cli_help.log').open('x') as log:
  subprocess.run(['sudo','-n','docker','exec','vllm051','python3','/vllm-workspace/vidur_cpu_overhead/vllm_051_cpu_overhead.py','--help'],stdout=log,stderr=subprocess.STDOUT,check=True)
 text=(R/'single_node_q9_cpu_cli_help.log').read_text()
 for flag in ['--pipeline-parallel-size','--profile-http-serving','--diagnostic-request-interval']:
  if flag not in text:raise RuntimeError('Profiler CLI is missing '+flag)
 for f in (S/'vidur').rglob('*.py'):result['files'].append(dict(path=str(P/f.relative_to(S)),sha256=sha(P/f.relative_to(S))))
 result.update(phase='complete',completed_at=time.time(),tests='61 unit tests passed in installed repository',cpu_entrypoint=str(CPU/'vllm_051_cpu_overhead.py'),cpu_entrypoint_sha256=sha(CPU/'vllm_051_cpu_overhead.py'),precision_note='Moving profile files retrains unseeded legacy random-forest regressors. The first exact-float check found a 0.019 ms difference; this final gate validates profile identity and actual mean-E2E accuracy rather than assuming bitwise identity.')
 save()
except Exception as error:
 result.update(phase='failed',error=repr(error));save();raise
