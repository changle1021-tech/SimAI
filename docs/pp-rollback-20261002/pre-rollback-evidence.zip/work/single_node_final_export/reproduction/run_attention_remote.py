import os,json,time,subprocess
from pathlib import Path
r=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
s=dict(pid=os.getpid(),phase='running',started_at_epoch=time.time())
def save():(r/'attention_state.json').write_text(json.dumps(s))
save()
try:
 with (r/'attention_capacity.log').open('w') as f:
  subprocess.run(['sudo','-n','docker','exec','vidur-pp2-residual-20261001','python3','/diagnostic/staging/scripts/profile_attention_capacity.py'],stdout=f,stderr=subprocess.STDOUT,check=True)
 s['phase']='complete';save()
except Exception as e:
 s.update(phase='failed',error=repr(e));save();raise
