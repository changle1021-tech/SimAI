import json,os,time,subprocess
from pathlib import Path
r=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');s=dict(pid=os.getpid(),phase='running',started_at_epoch=time.time())
def save():(r/'mlp_state.json').write_text(json.dumps(s))
save()
try:
 with (r/'mlp_component.log').open('w') as f:
  subprocess.run(['sudo','-n','docker','exec','vidur-operator-residual-20261001','python3','/diagnostic/staging/vidur/profiling/cpu_overhead/vllm_051_mlp_profile.py','--model','/mnt/data02/000000/model/Llama-2-7b-hf-bin-export','--tensor-parallel-sizes','1','2','--max-tokens','4096','--warmup','20','--repetitions','20','--vidur-vocab-size','32768','--output','/diagnostic/mlp_native_operators.csv'],stdout=f,stderr=subprocess.STDOUT,check=True)
 s['phase']='complete';save()
except Exception as e:s.update(phase='failed',error=repr(e));save();raise
