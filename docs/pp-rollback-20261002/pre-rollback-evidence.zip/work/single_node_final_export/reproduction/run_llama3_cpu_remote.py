import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
NAME = 'vidur-pp2-residual-20261001'


def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    state = {'pid': os.getpid(), 'phase': 'starting', 'started_at_epoch': time.time()}
    def save():
        (ROOT/'llama3_cpu_retry_state.json').write_text(json.dumps(state))
    save()
    try:
        # Refuse to grab GPUs that became busy after the initial inspection.
        raw = subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used',
                                       '--format=csv,noheader,nounits'], text=True)
        memory = {int(i):int(m) for i,m in (line.split(',') for line in raw.splitlines())}
        if any(memory[i] > 500 for i in [2,3]):
            raise RuntimeError(f'GPU2/3 became occupied: {memory}')
        existing = subprocess.check_output(['sudo','-n','docker','ps','-a','--format','{{.Names}}'], text=True).splitlines()
        if NAME not in existing:
            subprocess.run(['sudo','-n','docker','run','-d','--name',NAME,
                            '--gpus','"device=2,3"','--ipc','host',
                            '-e','CUDA_VISIBLE_DEVICES=0,1',
                            '-e','PYTHONPATH=/diagnostic/staging/vidur/profiling/cpu_overhead',
                            '-e','RAY_USAGE_STATS_ENABLED=0',
                            '-v','/mnt/data02:/mnt/data02:ro',
                            '-v',str(ROOT)+':/diagnostic',
                            '--entrypoint','sleep','docker.io/library/vllm:v0.5.1-trace','infinity'],
                           check=True)
        state['phase']='full_profile';save()
        args = ['sudo','-n','docker','exec',NAME,'python3',
                '/diagnostic/staging/vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py',
                '--model','/diagnostic/llama3_local',
                '--model-name-for-vidur','meta-llama/Meta-Llama-3-8B',
                '--tensor-parallel-size','1','--pipeline-parallel-size','2',
                '--profile-serving-loop','--executor-backend','ray','--batch-sizes','1','2','3','4',
                '--prompt-tokens','512','--decode-tokens','50',
                '--repetitions','3','--warmup-decode-tokens','8',
                '--max-model-len','4096','--max-num-seqs','8',
                '--max-num-batched-tokens','4096','--gpu-memory-utilization','0.2',
                '--load-format','auto','--seed','36',
                '--output','/diagnostic/llama3_cpu.csv']
        (ROOT/'llama3_cpu_launch.json').write_text(json.dumps(args,indent=2))
        with (ROOT/'llama3_cpu_retry_profile.log').open('w') as f:
            subprocess.run(args, stdout=f, stderr=subprocess.STDOUT,check=True)
        state['phase']='complete';save()
    except Exception as e:
        state.update(phase='failed',error=repr(e));save();raise


if __name__=='__main__':
    main()
