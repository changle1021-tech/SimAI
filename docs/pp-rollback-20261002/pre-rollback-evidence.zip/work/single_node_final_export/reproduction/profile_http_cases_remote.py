#!/usr/bin/env python3
"""Collect three isolated native vLLM measurements from an existing remote container.

This driver performs measurements only. It does not configure or run Vidur, modify
the container, deploy code, or overwrite existing result directories.
"""

import argparse
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
SERVER_SCRIPT = '/diagnostic/staging/scripts/vllm_051_http_profile_server.py'
CLIENT_SCRIPT = '/diagnostic/staging/scripts/vllm_benchmark_client.py'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--case-prefix', required=True)
    parser.add_argument('--container', required=True)
    parser.add_argument('--model-path', required=True)
    parser.add_argument('--served-model', required=True)
    parser.add_argument('--tp', required=True, type=int)
    parser.add_argument('--pp', required=True, type=int)
    parser.add_argument('--network-transport', default='local')
    parser.add_argument('--profile-model-name', required=True)
    args = parser.parse_args()

    if not args.case_prefix.replace('-', '').replace('_', '').isalnum():
        parser.error("--case-prefix must contain only letters, digits, '_' or '-'")
    if args.tp < 1 or args.pp < 1:
        parser.error('--tp and --pp must be positive')

    state_path = ROOT / f'{args.case_prefix}_evaluation_state.json'
    driver_dir = ROOT / f'{args.case_prefix}_driver'
    cases = [ROOT / f'{args.case_prefix}_{i}' for i in range(3)]
    ROOT.mkdir(parents=True, exist_ok=True)
    # Never reuse results or an old PID record from an earlier evaluation.
    if state_path.exists() or driver_dir.exists() or any(case.exists() for case in cases):
        raise FileExistsError('Evaluation output already exists; refusing to overwrite it')

    state = {'pid': os.getpid(), 'phase': 'starting', 'started_at_epoch': time.time(),
             'case_prefix': args.case_prefix, 'container': args.container,
             'model_path': args.model_path, 'served_model': args.served_model,
             'tp': args.tp, 'pp': args.pp}

    def save_state():
        state_path.write_text(json.dumps(state, indent=2) + '\n')

    def docker_exec(*command, **kwargs):
        return subprocess.run(['sudo', '-n', 'docker', 'exec', args.container,
                               *command], check=True, **kwargs)

    server = None
    server_log = None
    save_state()
    try:
        launch = [
            'python3', SERVER_SCRIPT,
            '--diagnostic-output', f'/diagnostic/{args.case_prefix}_driver',
            '--model', args.model_path,
            '--served-model-name', args.served_model,
            '--load-format', 'auto', '--disable-custom-all-reduce',
            '--dtype', 'float16', '--max-model-len', '4096',
            '--tensor-parallel-size', str(args.tp),
            '--pipeline-parallel-size', str(args.pp),
            '--seed', '36', '--distributed-executor-backend', 'ray',
            '--gpu-memory-utilization', '0.8', '--block-size', '16',
            '--max-num-seqs', '8', '--max-num-batched-tokens', '4096',
            '--max-seq-len-to-capture', '4096', '--disable-log-stats',
            '--host', '127.0.0.1', '--port', '8089',
        ]
        (ROOT / f'{args.case_prefix}_server_launch.json').write_text(
            json.dumps(launch, indent=2) + '\n')
        state.update(phase='server_starting')
        save_state()
        server_log = (ROOT / f'{args.case_prefix}_server.log').open('x')
        server = subprocess.Popen(['sudo', '-n', 'docker', 'exec', args.container,
                                   *launch], stdout=server_log, stderr=subprocess.STDOUT)
        state['server_exec_pid'] = server.pid
        save_state()

        for _ in range(120):
            if server.poll() is not None:
                raise RuntimeError('API service exited during startup')
            health = subprocess.run(
                ['sudo', '-n', 'docker', 'exec', args.container, 'python3', '-c',
                 "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8089/health', timeout=2).close()"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if health.returncode == 0:
                break
            time.sleep(2)
        else:
            raise RuntimeError('API health startup timeout')

        state.update(phase='profiling');save_state()
        launch=['python3','/diagnostic/staging/scripts/vllm_051_http_profile_client.py',
            '--server-output',f'/diagnostic/{args.case_prefix}_driver',
            '--model-name',args.served_model,'--model-name-for-vidur',args.profile_model_name,
            '--tp',str(args.tp),'--pp',str(args.pp),'--batch-sizes','1','2','3','4',
            '--repetitions','5','--network-transport',args.network_transport,
            '--output',f'/diagnostic/{args.case_prefix}_cpu.csv']
        with (ROOT/f'{args.case_prefix}_client.log').open('x') as log:
            docker_exec(*launch,stdout=log,stderr=subprocess.STDOUT)
        state.update(phase='complete', completed_at_epoch=time.time())
        save_state()
    except Exception as exc:
        state.update(phase='failed', error=repr(exc), failed_at_epoch=time.time())
        save_state()
        raise
    finally:
        # Stop only the vLLM process whose recorded cmdline names this script and prefix.
        stop_check = (
            "import os,signal,sys; "
            f"p='/diagnostic/{args.case_prefix}_driver/server_pid.txt'; "
            "pid=int(open(p).read().strip()); "
            "cmd=open(f'/proc/{pid}/cmdline','rb').read().decode(errors='replace').replace('\\x00',' '); "
            f"script={SERVER_SCRIPT!r}; prefix={args.case_prefix!r}; "
            "(os.kill(pid,signal.SIGTERM) if script in cmd and prefix in cmd "
            "else sys.exit('refusing to signal PID: cmdline does not match script and prefix'))"
        )
        if server is not None:
            subprocess.run(['sudo', '-n', 'docker', 'exec', args.container,
                            'python3', '-c', stop_check], check=False)
            try:
                server.wait(timeout=30)
            except subprocess.TimeoutExpired:
                state.update(phase='server_stop_timeout', updated_at_epoch=time.time())
                save_state()
        if server_log is not None:
            server_log.close()


if __name__ == '__main__':
    main()
