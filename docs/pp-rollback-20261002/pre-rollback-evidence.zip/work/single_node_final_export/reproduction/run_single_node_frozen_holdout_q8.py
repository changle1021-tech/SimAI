"""Frozen physical profiles; independent native holdouts, no E2E feedback."""
import csv,json,time,subprocess,hashlib,os
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
PY='/home/turbo_ops/miniconda3/envs/sarathi/bin/python'
S=R/'staging'
STATE=R/'single_node_frozen_holdout_q8_state.json'
if STATE.exists():raise FileExistsError('Keep existing holdout results')
state=dict(pid=os.getpid(),phase='prepare',started_at=time.time(),completed=[])
def save():STATE.write_text(json.dumps(state,indent=2))
def run(cmd,label):
 state['phase']=label;save()
 with (R/(label+'.log')).open('x') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('COMPLETE',label,flush=True)
save()
try:
 # Publish the physical descriptor without fitting measured request times.
 rows=[r for r in csv.DictReader((R/'native_decoder_graph.csv').open()) if int(r['num_tensor_parallel_workers'])==1]
 full=list(csv.DictReader((R/'native_decoder_graph_tp_group_q8.csv').open()))
 for row in full:row['model_name']='meta-llama/Llama-2-7b-hf'
 rows+=full;fields=list(dict.fromkeys(k for row in rows for k in row))
 target=R/'native_decoder_graph_combined_q8.csv'
 if target.exists():raise FileExistsError('Do not replace frozen GPU profiles')
 with target.open('x',newline='') as stream:
  writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader();writer.writerows(rows)
 cases=[
 dict(name='l2_tp1pp2',model='meta-llama/Llama-2-7b-hf',path='/mnt/data02/000000/model/Llama-2-7b-hf-bin-export',tp=1,pp=2,cpu='single_l2_tp1pp2_q7_cpu_program.csv',loop='http_serving_spaced_diagnostic',container='vidur-pp2-residual-20261001'),
 dict(name='l2_tp2pp2',model='meta-llama/Llama-2-7b-hf',path='/mnt/data02/000000/model/Llama-2-7b-hf-bin-export',tp=2,pp=2,cpu='single_l2_tp2pp2_q7_cpu_program.csv',loop='http_serving_spaced_diagnostic',container='vidur-tp2pp2-residual-20261001'),
 dict(name='l2_tp1pp3',model='meta-llama/Llama-2-7b-hf',path='/mnt/data02/000000/model/Llama-2-7b-hf-bin-export',tp=1,pp=3,cpu='single_l2_tp1pp3_v2_cpu_program.csv',loop='http_serving',container='vidur-tp2pp2-residual-20261001'),
 dict(name='l3_tp1pp2',model='meta-llama/Meta-Llama-3-8B',path='/diagnostic/llama3_local',tp=1,pp=2,cpu='single_l3_tp1pp2_v2_cpu_program.csv',loop='http_serving',container='vidur-pp2-residual-20261001',llama3=True),
 ]
 files=[target,R/'native_collectives_single_node.csv',*[R/c['cpu'] for c in cases]]
 files+=list((S/'vidur').rglob('*.py'))
 for file in files:
  if not file.is_file():raise FileNotFoundError(file)
 manifest={str(f.relative_to(R)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
 (R/'single_node_frozen_holdout_q8_manifest.json').write_text(json.dumps(manifest,indent=2))
 state['verification']='10 original three-request rounds per case; 512/50; all results retained; code/profiles frozen before native measurements';save()
 run([PY,str(S/'repair_overlay_remote.py')],'q8_overlay_gate')
 for case in cases:
  name='q8_holdout_'+case['name'];prefix=name+'_native'
  run(['sudo','-n','docker','restart',case['container']],name+'_restart_native')
  run([PY,str(S/'evaluate_broad_cases_adequate_sample_remote.py'),'--case-prefix',prefix,'--container',case['container'],'--model-path',case['path'],'--served-model',case['model'],'--tp',str(case['tp']),'--pp',str(case['pp']),'--unmodified-server','--rounds','10'],name+'_native')
  replay=[PY,str(S/'replay_validation_matrix_remote.py'),'--label',name+'_program','--case-prefix',prefix,'--cpu',case['cpu'],'--model',case['model'],'--tp',str(case['tp']),'--pp',str(case['pp']),'--rank-map',json.dumps([0]*(case['tp']*case['pp'])),'--loop',case['loop'],'--all-reduce','native_collectives_single_node.csv','--rounds','10']
  if case.get('llama3'):replay.append('--llama3')
  else:replay+=['--decoder-graph',target.name]
  run(replay,name+'_replay')
  for path,sha in manifest.items():
   if hashlib.sha256((R/path).read_bytes()).hexdigest()!=sha:raise RuntimeError('Frozen source or profile changed: '+path)
  result=json.loads((R/(name+'_program_comparison.json')).read_text())
  state['completed'].append(result);save()
 state.update(phase='complete',completed_at=time.time());save()
except Exception as error:
 state.update(phase='failed',error=repr(error));save();raise
