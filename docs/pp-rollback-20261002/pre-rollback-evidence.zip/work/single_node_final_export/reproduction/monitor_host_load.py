"""Read-only host conditions alongside validation, with bounded owned lifetime."""
import argparse,json,os,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--duration',type=float,default=3600);a=p.parse_args()
path=Path(a.output);path.with_suffix('.pid').write_text(str(os.getpid()))
deadline=time.monotonic()+a.duration
with path.open('x',buffering=1) as stream:
 while time.monotonic()<deadline:
  row=dict(epoch=time.time(),loadavg=Path('/proc/loadavg').read_text().strip(),
   cpu_pressure=Path('/proc/pressure/cpu').read_text().strip(),
   cpu_stat=Path('/proc/stat').read_text().splitlines()[0],
   network=Path('/proc/net/dev').read_text())
  try:row['gpu']=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used,utilization.gpu,clocks.sm,temperature.gpu,power.draw','--format=csv,noheader,nounits'],text=True,timeout=2)
  except Exception as exc:row['gpu_error']=repr(exc)
  stream.write(json.dumps(row)+'\n');time.sleep(4)
