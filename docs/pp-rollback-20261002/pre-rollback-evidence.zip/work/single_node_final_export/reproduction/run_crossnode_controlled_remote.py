"""Sequential independent holdouts and primitive profiles; never fit request latency."""
import argparse,json,os,subprocess,time
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
S=R/'staging'; C='vidur-crossnode-residual-20261001'
PY='/home/turbo_ops/miniconda3/envs/sarathi/bin/python'
parser=argparse.ArgumentParser();parser.add_argument('--resume-after-pp2',action='store_true');args=parser.parse_args()
state=dict(pid=os.getpid(),phase='waiting',started_at_epoch=time.time(),resume_after_pp2=args.resume_after_pp2)
previous=R/'crossnode_controlled_state.json'
if previous.exists():
 old=json.loads(previous.read_text())
 if old['phase']!='failed':raise RuntimeError('Only a failed owned sequence may be resumed')
 (R/f'crossnode_controlled_previous_{old["pid"]}.json').write_text(json.dumps(old,indent=2))
def save():(R/'crossnode_controlled_state.json').write_text(json.dumps(state,indent=2))
def run(label,command):
 state.update(phase=label,command=command);save()
 with (R/f'{label}.log').open('x') as log:
  subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
def evaluate(prefix,tp,pp):
 run(prefix,[PY,str(S/'evaluate_broad_cases_remote.py'),'--case-prefix',prefix,
 '--container',C,'--model-path','/mnt/data02/000000/model/Llama-2-7b-hf-bin-export',
 '--served-model','Llama-2-7b-hf','--tp',str(tp),'--pp',str(pp)])
def replay(label,prefix,cpu,tp,pp,collective=None):
 args=[PY,str(S/'replay_validation_matrix_remote.py'),'--label',label,'--case-prefix',prefix,
 '--cpu',cpu,'--tp',str(tp),'--pp',str(pp),'--rank-map','[0,1]',
 '--loop','http_serving','--transport','socket']
 if collective:args.extend(['--all-reduce',collective])
 run(label+'_launcher',args)
try:
 save()
 # Separate native measurements from other owned profiling and replay jobs.
 for _ in range(7200):
  statuses=[json.loads((R/f'{x}_replay_state.json').read_text()).get('phase') if (R/f'{x}_replay_state.json').exists() else 'waiting'
   for x in ['llama2_pp3_dag_v4','llama2_tp2pp2_http_dag']]
  if (R/'native_collectives_crossnode.csv').exists() and all(x in ['complete','failed'] for x in statuses):break
  time.sleep(1)
 else:raise RuntimeError('Prerequisite experiments did not finish')
 memory={int(i):int(m) for i,m in (line.split(',') for line in subprocess.check_output(
 ['nvidia-smi','--query-gpu=index,memory.used','--format=csv,noheader,nounits'],text=True).splitlines())}
 if any(memory[i]>1000 for i in [2,3,4,5]):raise RuntimeError(f'Owned local GPUs remain occupied: {memory}')
 (R/'controlled_start_environment.json').write_text(json.dumps(dict(gpu_memory=memory,
 loadavg=Path('/proc/loadavg').read_text(),cpu_pressure=Path('/proc/pressure/cpu').read_text(),
 link_speed_mbps=Path('/sys/class/net/enp159s0f0/speed').read_text(),time=time.time()),indent=2))
 if not args.resume_after_pp2:
  evaluate('crossnode_pp2_controlled',1,2)
  replay('crossnode_pp2_controlled_dag','crossnode_pp2_controlled','crossnode_http_v3_cpu.csv',1,2)
 run('crossnode_tp2_http_profile_retry1' if args.resume_after_pp2 else 'crossnode_tp2_http_profile',['sudo','-n','docker','exec',C,'python3',
 '/diagnostic/staging/vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py',
 '--model','/mnt/data02/000000/model/Llama-2-7b-hf-bin-export',
 '--model-name-for-vidur','meta-llama/Llama-2-7b-hf','--tensor-parallel-size','2',
 '--pipeline-parallel-size','1','--profile-http-serving','--executor-backend','ray',
 '--network-transport','socket','--batch-sizes','1','2','3','4','--prompt-tokens','512',
 '--decode-tokens','50','--repetitions','5','--max-model-len','4096','--max-num-seqs','8',
 '--max-num-batched-tokens','4096','--gpu-memory-utilization','0.2','--load-format','auto',
 '--seed','36','--output','/diagnostic/crossnode_tp2_http_cpu.csv'])
 evaluate('crossnode_tp2_native',2,1)
 replay('crossnode_tp2_native_dag','crossnode_tp2_native','crossnode_tp2_http_cpu.csv',2,1,
 'native_collectives_crossnode.csv')
 state.update(phase='complete',completed_at_epoch=time.time());save()
except Exception as exc:
 state.update(phase='failed',error=repr(exc));save();raise
