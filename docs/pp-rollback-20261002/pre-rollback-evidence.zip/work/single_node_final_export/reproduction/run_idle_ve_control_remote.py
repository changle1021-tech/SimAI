import ast
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
from typing import List, Dict, Any

ROOT=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
STAGE=ROOT/'staging'
REPO=Path('/home/turbo_ops/changle/SimAI/vidur-alibabacloud')
CPU_DIR=Path('/home/turbo_ops/changle/Files/vidur_cpu_overhead')
NAME='vidur-pp2-residual-20261001'
PY='/home/turbo_ops/miniconda3/envs/sarathi/bin/python'


def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def deploy():
    if json.loads((ROOT/'full_profile_state.json').read_text())['phase']!='complete':
        raise RuntimeError('Full profile is not complete')
    profiles=list(csv.DictReader((ROOT/'pp2_cpu.csv').open()))
    if len(profiles)!=16 or {r['phase'] for r in profiles}!={'prefill','decode'}:
        raise RuntimeError('Incomplete PP2 profile')
    for row in profiles:
        if int(row['pipeline_parallel_degree'])!=2 or int(row['tensor_parallel_degree'])!=1:
            raise RuntimeError('Unexpected parallelism in PP2 profile')
    backup=ROOT/'backups';backup.mkdir(exist_ok=True)
    manifest=json.loads((STAGE/'deploy_manifest.json').read_text())
    target=REPO/'vidur/execution_time_predictor/sklearn_execution_time_predictor.py'
    if digest(target) not in [manifest['predictor_original_sha256'], digest(STAGE/'vidur/execution_time_predictor/sklearn_execution_time_predictor.py')]:
        raise RuntimeError('Predictor changed since inspection; refusing to overwrite other work')
    profiler=CPU_DIR/'vllm_051_cpu_overhead.py'
    if digest(profiler) not in [manifest['cpu_profiler_original_sha256'], digest(STAGE/'vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py')]:
        raise RuntimeError('CPU profiler changed since inspection')
    for source,name,expected in [
        (target,'sklearn_execution_time_predictor.py',manifest['predictor_original_sha256']),
        (profiler,'vllm_051_cpu_overhead.py',manifest['cpu_profiler_original_sha256'])]:
        if not (backup/name).exists():shutil.copy2(source,backup/name)
        if digest(backup/name)!=expected:raise RuntimeError('Original backup does not match inspected source')
    if not (backup/'cpu_overheads.csv').exists():
        shutil.copy2(CPU_DIR/'cpu_overheads.csv',backup/'cpu_overheads.csv')
    shutil.copy2(target.with_name('base_execution_time_predictor.py'),backup/'base_execution_time_predictor.py')
    shutil.copy2(STAGE/'vidur/execution_time_predictor/sklearn_execution_time_predictor.py',target)
    for p in (STAGE/'vidur/profiling/cpu_overhead').glob('*.py'):
        shutil.copy2(p,REPO/'vidur/profiling/cpu_overhead'/p.name)
        subprocess.run(['sudo','-n','cp',str(p),str(CPU_DIR/p.name)],check=True)
    for p in (STAGE/'tests').glob('test_pp*.py'):
        shutil.copy2(p,REPO/'tests'/p.name)
    shutil.copy2(STAGE/'docs/pp_cpu_profiling.md',REPO/'docs/pp_cpu_profiling.md')
    subprocess.run(['sudo','-n','docker','exec','vllm051','mkdir','-p',
                    '/vllm-workspace/vidur_cpu_overhead'],check=True)
    for p in (STAGE/'vidur/profiling/cpu_overhead').glob('*.py'):
        subprocess.run(['sudo','-n','docker','cp',str(p),
                        'vllm051:/vllm-workspace/vidur_cpu_overhead/'+p.name],check=True)
    # Use the same CSV writer as the CLI; migrate only the legacy PP dimension.
    source=STAGE/'vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py'
    node=next(n for n in ast.parse(source.read_text()).body
              if isinstance(n,ast.FunctionDef) and n.name=='_write_rows')
    env=dict(Path=Path,List=List,Dict=Dict,Any=Any,csv=csv)
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),env)
    merged_path=ROOT/'merged_cpu_overheads.csv'
    shutil.copy2(backup/'cpu_overheads.csv',merged_path)
    env['_write_rows'](merged_path,profiles,True)
    subprocess.run(['sudo','-n','cp',str(merged_path),str(CPU_DIR/'cpu_overheads.csv')],check=True)
    merged=list(csv.DictReader((CPU_DIR/'cpu_overheads.csv').open()))
    old=list(csv.DictReader((backup/'cpu_overheads.csv').open()))
    if len(merged)!=len(old)+16:raise RuntimeError('CPU merge count mismatch')
    for before,after in zip(old,merged):
        if any(after[k]!=v for k,v in before.items()):raise RuntimeError('Legacy CPU labels changed')
    (ROOT/'deployment.json').write_text(json.dumps(dict(
        cpu_csv=str(CPU_DIR/'cpu_overheads.csv'),cpu_csv_sha256=digest(CPU_DIR/'cpu_overheads.csv'),
        predictor_sha256=digest(target),legacy_rows=len(old),new_pp2_rows=16,
        backups=str(backup)),indent=2))
    with (ROOT/'tests.log').open('w') as stream:
        subprocess.run([PY,'-m','unittest','discover','-s','tests','-p','test_*.py','-v'],
                       cwd=REPO,stdout=stream,stderr=subprocess.STDOUT,check=True)


def evaluate(state,save):
    launch=['python3','/diagnostic/staging/scripts/vllm_051_idle_ve_audit.py',
            '--active-ve-wait-control','--diagnostic-output','/diagnostic/idle_ve_audit_control',
            '--model','/mnt/data02/000000/model/Llama-2-7b-hf-bin-export',
            '--served-model-name','Llama-2-7b-hf','--load-format','auto',
            '--disable-custom-all-reduce','--dtype','float16',
            '--max-model-len','4096','--tensor-parallel-size','1','--pipeline-parallel-size','2',
            '--seed','36','--distributed-executor-backend','ray','--gpu-memory-utilization','0.8',
            '--block-size','16','--max-num-seqs','8','--max-num-batched-tokens','4096',
            '--max-seq-len-to-capture','4096','--disable-log-stats',
            '--host','127.0.0.1','--port','8089']
    (ROOT/'api_idle_ve_control_launch.json').write_text(json.dumps(launch,indent=2))
    state['phase']='api_starting';save()
    stream=(ROOT/'api_idle_ve_control_server.log').open('w')
    server=subprocess.Popen(['sudo','-n','docker','exec',NAME,*launch],stdout=stream,stderr=subprocess.STDOUT)
    state['api_exec_pid']=server.pid;save()
    try:
        for _ in range(120):
            if server.poll() is not None:raise RuntimeError('API service exited during startup')
            health=subprocess.run(['sudo','-n','docker','exec',NAME,'python3','-c',
                "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8089/health',timeout=2).close()"],
                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            if health.returncode==0:break
            time.sleep(2)
        else:raise RuntimeError('API health startup timeout')
        for run in range(1):
            state.update(phase='api_benchmark',round=run);save()
            case=ROOT/f'idle_ve_control_{run}';case.mkdir(exist_ok=False)
            args=['sudo','-n','docker','exec',NAME,'python3','/diagnostic/staging/scripts/vllm_benchmark_client.py',
                  '--host','127.0.0.1','--port','8089','--model','Llama-2-7b-hf',
                  '--num-requests','3','--qps','0.3','--prefill-tokens','512','--decode-tokens','50',
                  '--seed','36','--warmup-requests','5','--ignore-eos',
                  '--output-dir',f'/diagnostic/idle_ve_control_{run}','--output-file','vllm.json',
                  '--trace-output-file',f'/diagnostic/idle_ve_control_{run}/arrival_trace.csv']
            (case/'client_launch.json').write_text(json.dumps(args,indent=2))
            with (case/'client.log').open('w') as f:
                subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)
            result=json.loads((case/'vllm.json').read_text())
            if len(result['requests'])!=3 or any(r.get('actual_completion_tokens')!=50 or r.get('actual_prompt_tokens')!=512 for r in result['requests']):
                raise RuntimeError('Holdout failed token or request count validation')
            print('PROFILE_ROUND',run,json.dumps(result['summary']),flush=True)
    finally:
        # Stop only the diagnostic container created by this task.
        subprocess.run(['sudo','-n','docker','exec',NAME,'python3','-c',
            "import os,signal; os.kill(int(open('/diagnostic/idle_ve_audit_control/server_pid.txt').read()),signal.SIGTERM)"],
            check=False)
        try:
            server.wait(timeout=30)
        finally:
            pass # Keep the isolated container for later validation.
            stream.close()
def main():
    state=dict(pid=os.getpid(),phase='deploying',started_at_epoch=time.time())
    def save():(ROOT/'api_idle_ve_control_state.json').write_text(json.dumps(state))
    save()
    try:
        evaluate(state,save)
        state['phase']='complete';save()
    except Exception as e:
        state.update(phase='failed',error=repr(e));save();raise


if __name__=='__main__':main()
