import os,json,subprocess,time
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');S=R/'staging';s=dict(pid=os.getpid(),phase='starting',started_at_epoch=time.time())
def save():(R/'parallel_modes_state.json').write_text(json.dumps(s))
save()
try:
 for tp,pp,name in [(2,1,'vidur-operator-residual-20261001'),(2,2,'vidur-tp2pp2-residual-20261001'),(1,3,'vidur-tp2pp2-residual-20261001')]:
  prefix=f'llama2_tp{tp}pp{pp}'
  if tp*pp>2:
   s['phase']='waiting_for_llama3_validation';save()
   for _ in range(90):
    f=R/'llama3_pp2_native_evaluation_state.json'
    if f.exists() and json.loads(f.read_text())['phase']=='complete':break
    time.sleep(5)
   else:raise RuntimeError('Llama3 native job did not complete')
   names=subprocess.check_output(['sudo','-n','docker','ps','-a','--format','{{.Names}}'],text=True).splitlines()
   if name not in names:
    memory={int(i):int(m) for i,m in (x.split(',') for x in subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used','--format=csv,noheader,nounits'],text=True).splitlines())}
    if any(memory[x]>500 for x in [2,3,4,5]):raise RuntimeError(f'Owned diagnostic GPUs still occupied: {memory}')
    subprocess.run(['sudo','-n','docker','run','-d','--name',name,'--gpus','"device=2,3,4,5"','--ipc','host','-e','CUDA_VISIBLE_DEVICES=0,1,2,3','-e','PYTHONPATH=/diagnostic/staging/vidur/profiling/cpu_overhead','-e','RAY_USAGE_STATS_ENABLED=0','-v','/mnt/data02:/mnt/data02:ro','-v',str(R)+':/diagnostic','--entrypoint','sleep','docker.io/library/vllm:v0.5.1-trace','infinity'],check=True)
  s.update(phase='profiling',tp=tp,pp=pp);save()
  args=['sudo','-n','docker','exec',name,'python3','/diagnostic/staging/vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py','--model','/mnt/data02/000000/model/Llama-2-7b-hf-bin-export','--model-name-for-vidur','meta-llama/Llama-2-7b-hf','--tensor-parallel-size',str(tp),'--pipeline-parallel-size',str(pp),'--profile-serving-loop','--executor-backend','ray','--batch-sizes','1','2','3','4','--prompt-tokens','512','--decode-tokens','50','--repetitions','5','--max-model-len','4096','--max-num-seqs','8','--max-num-batched-tokens','4096','--gpu-memory-utilization','0.2','--load-format','auto','--seed','36','--output',f'/diagnostic/{prefix}_cpu.csv']
  (R/f'{prefix}_profile_launch.json').write_text(json.dumps(args,indent=2))
  with (R/f'{prefix}_profile.log').open('w') as log:subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
  s['phase']='actual_measurement';save()
  args=['python3',str(S/'evaluate_broad_cases_remote.py'),'--case-prefix',prefix+'_native','--container',name,'--model-path','/mnt/data02/000000/model/Llama-2-7b-hf-bin-export','--served-model','Llama-2-7b-hf','--tp',str(tp),'--pp',str(pp)]
  with (R/f'{prefix}_native_launcher.log').open('w') as log:subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
 s['phase']='complete';save()
except Exception as e:s.update(phase='failed',error=repr(e));save();raise
