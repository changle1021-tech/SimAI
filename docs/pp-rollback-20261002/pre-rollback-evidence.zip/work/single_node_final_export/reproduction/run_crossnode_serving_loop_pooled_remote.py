import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
NAME = 'vidur-crossnode-residual-20261001'


def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    state = {'pid': os.getpid(), 'phase': 'starting', 'started_at_epoch': time.time()}
    def save():
        (ROOT/'crossnode_serving_loop_pooled_state.json').write_text(json.dumps(state))
    save()
    try:
        # This container and its two-node Ray cluster belong to this diagnostic.
        state['phase']='full_profile';save()
        args = ['sudo','-n','docker','exec',NAME,'python3',
                '/diagnostic/staging/vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py',
                '--model','/mnt/data02/000000/model/Llama-2-7b-hf-bin-export',
                '--model-name-for-vidur','meta-llama/Llama-2-7b-hf',
                '--tensor-parallel-size','1','--pipeline-parallel-size','2',
                '--network-transport','socket','--profile-serving-loop','--executor-backend','ray','--batch-sizes','1','2','3','4',
                '--prompt-tokens','512','--decode-tokens','50',
                '--repetitions','5','--warmup-decode-tokens','8',
                '--max-model-len','4096','--max-num-seqs','8',
                '--max-num-batched-tokens','4096','--gpu-memory-utilization','0.2',
                '--load-format','auto','--seed','36',
                '--output','/diagnostic/cpu_crossnode_serving_loop_pooled.csv']
        (ROOT/'crossnode_serving_loop_pooled_launch.json').write_text(json.dumps(args,indent=2))
        with (ROOT/'crossnode_serving_loop_pooled_profile.log').open('w') as f:
            subprocess.run(args, stdout=f, stderr=subprocess.STDOUT,check=True)
        state['phase']='complete';save()
    except Exception as e:
        state.update(phase='failed',error=repr(e));save();raise


if __name__=='__main__':
    main()
