"""Sequential single-node primitive profiles and untouched-native holdouts."""
import argparse, csv, json, os, subprocess, time
from pathlib import Path

ROOT=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
PY='/home/turbo_ops/miniconda3/envs/sarathi/bin/python'
CASES=[
    dict(name='single_l2_tp1pp2',tp=1,pp=2,container='vidur-pp2-residual-20261001',
         model='meta-llama/Llama-2-7b-hf',path='/mnt/data02/000000/model/Llama-2-7b-hf-bin-export'),
    dict(name='single_l2_tp2pp2',tp=2,pp=2,container='vidur-tp2pp2-residual-20261001',
         model='meta-llama/Llama-2-7b-hf',path='/mnt/data02/000000/model/Llama-2-7b-hf-bin-export'),
    dict(name='single_l2_tp1pp3',tp=1,pp=3,container='vidur-tp2pp2-residual-20261001',
         model='meta-llama/Llama-2-7b-hf',path='/mnt/data02/000000/model/Llama-2-7b-hf-bin-export'),
    dict(name='single_l3_tp1pp2',tp=1,pp=2,container='vidur-pp2-residual-20261001',
         model='meta-llama/Meta-Llama-3-8B',path='/diagnostic/llama3_local',llama3=True),
]
parser=argparse.ArgumentParser()
parser.add_argument('--run-id',required=True)
options=parser.parse_args()
if not options.run_id.replace('_','').isalnum():raise ValueError('Invalid run identifier')
for case in CASES:case['name']+='_'+options.run_id
state_file=ROOT/('single_node_program_validation_'+options.run_id+'_state.json')
if state_file.exists():
    raise FileExistsError('Validation run already exists; keep all original results')
state=dict(pid=os.getpid(),phase='starting',started_at_epoch=time.time(),completed=[])
def save():state_file.write_text(json.dumps(state,indent=2))
def run(command,label):
    state.update(phase=label);save()
    with (ROOT/(label+'.log')).open('x') as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    print('COMPLETE',label,flush=True)
save()
try:
    for case in CASES:
        name=case['name'];cpu=name+'_cpu_program.csv'
        # These containers belong exclusively to this investigation. Restart
        # only between our completed jobs to release their idle Ray workers.
        run(['sudo','-n','docker','restart',case['container']],name+'_restart_profile')
        command=['sudo','-n','docker','exec','-e',
            'PYTHONPATH=/diagnostic/staging/vidur/profiling/cpu_overhead',case['container'],
            'python3','/diagnostic/staging/vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py',
            '--model',case['path'],'--model-name-for-vidur',case['model'],
            '--load-format','auto','--seed','36',
            '--batch-sizes','1','2','3','4','--prompt-tokens','512','--decode-tokens','50',
            '--max-model-len','4096','--max-num-seqs','8','--max-num-batched-tokens','4096',
            '--gpu-memory-utilization','0.8','--tensor-parallel-size',str(case['tp']),
            '--pipeline-parallel-size',str(case['pp']),'--executor-backend','ray',
            '--profile-http-serving','--output','/diagnostic/'+cpu]
        run(command,name+'_profile')
        rows=list(csv.DictReader((ROOT/cpu).open()))
        if len(rows)!=8 or {int(r['profile_schema_version']) for r in rows}!={8}:
            raise ValueError('Missing complete named protocol/CPU producer profiles')
        run([PY,str(ROOT/'staging/repair_overlay_remote.py')],name+'_overlay_gate')
        run(['sudo','-n','docker','restart',case['container']],name+'_restart_native')
        prefix=name+'_untouched_native'
        run([PY,str(ROOT/'staging/evaluate_broad_cases_remote.py'),'--case-prefix',prefix,
             '--container',case['container'],'--model-path',case['path'],
             '--served-model',case['model'],'--tp',str(case['tp']),'--pp',str(case['pp']),
             '--unmodified-server'],name+'_native')
        replay=[PY,str(ROOT/'staging/replay_validation_matrix_remote.py'),
                '--label',name+'_program','--case-prefix',prefix,'--cpu',cpu,
                '--model',case['model'],'--tp',str(case['tp']),'--pp',str(case['pp']),
                '--rank-map',json.dumps([0]*(case['tp']*case['pp'])),
                '--loop','http_serving','--all-reduce','native_collectives_single_node.csv']
        if case.get('llama3'):replay.append('--llama3')
        run(replay,name+'_replay')
        result=json.loads((ROOT/(name+'_program_comparison.json')).read_text())
        state['completed'].append(result);save()
    state.update(phase='complete',completed_at_epoch=time.time());save()
except Exception as error:
    state.update(phase='failed',error=repr(error),failed_at_epoch=time.time());save();raise
