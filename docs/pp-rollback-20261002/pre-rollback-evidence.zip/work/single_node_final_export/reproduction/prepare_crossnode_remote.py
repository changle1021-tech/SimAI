import json,os,subprocess,socket,sys
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');N='vidur-crossnode-residual-20261001'
node=int(sys.argv[1]);gpu=6 if node==101 else 2;ip=f'172.16.30.{node}'
raw=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used','--format=csv,noheader,nounits'],text=True)
mem={int(i):int(m) for i,m in (s.split(',') for s in raw.splitlines())}
if mem[gpu]>500:raise RuntimeError(f'GPU{gpu} occupied: {mem[gpu]}')
existing=subprocess.check_output(['sudo','-n','docker','ps','-a','--format','{{.Names}}'],text=True).splitlines()
if N in existing:raise RuntimeError('Diagnostic cross-node container already exists; inspect and reuse')
R.mkdir(parents=True,exist_ok=True)
args=['sudo','-n','docker','run','-d','--name',N,'--gpus',f'"device={gpu}"','--ipc','host','--network','host',
 '--device','/dev/infiniband','-e','CUDA_VISIBLE_DEVICES=0','-e',f'VLLM_HOST_IP={ip}',
 '-e','PYTHONPATH=/diagnostic/staging/vidur/profiling/cpu_overhead','-e','RAY_USAGE_STATS_ENABLED=0',
 '-e','RAY_ADDRESS=172.16.30.101:26379','-e','NCCL_DEBUG=INFO',
 '-e',f'NCCL_SOCKET_IFNAME={"enp159s0f0" if node==101 else "enp210s0f1"}',
 '-v','/mnt/data02:/mnt/data02:ro','-v',str(R)+':/diagnostic',
 '--entrypoint','sleep','docker.io/library/vllm:v0.5.1-trace','infinity']
subprocess.run(args,check=True)
print(json.dumps(dict(node=node,gpu=gpu,container=N,command=args)),flush=True)
