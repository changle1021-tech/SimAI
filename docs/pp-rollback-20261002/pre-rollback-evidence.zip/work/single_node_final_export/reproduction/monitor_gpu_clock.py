"""Poll NVML physical GPU clocks without launching CUDA work."""
import argparse,ctypes,json,os,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--device',type=int,required=True);p.add_argument('--output',required=True);p.add_argument('--duration',type=float,default=3600);p.add_argument('--interval',type=float,default=.1);a=p.parse_args()
if a.interval<.01:raise ValueError('Monitor interval must be at least 10 ms')
library=ctypes.CDLL('libnvidia-ml.so.1')
def check(result):
 if result:raise RuntimeError(f'NVML returned {result}')
check(library.nvmlInit_v2())
handle=ctypes.c_void_p();check(library.nvmlDeviceGetHandleByIndex_v2(ctypes.c_uint(a.device),ctypes.byref(handle)))
path=Path(a.output);path.with_suffix('.pid').write_text(str(os.getpid()));deadline=time.monotonic()+a.duration
try:
 with path.open('x',buffering=1) as stream:
  while time.monotonic()<deadline:
   row=dict(epoch=time.time(),monotonic_ns=time.perf_counter_ns(),gpu_index=a.device)
   for name,function,args in [('sm_mhz','nvmlDeviceGetClockInfo',(ctypes.c_uint(1),)),
    ('memory_mhz','nvmlDeviceGetClockInfo',(ctypes.c_uint(2),)),
    ('power_mw','nvmlDeviceGetPowerUsage',()),('temperature_c','nvmlDeviceGetTemperature',(ctypes.c_uint(0),)),
    ('pstate','nvmlDeviceGetPerformanceState',())]:
    value=ctypes.c_uint();check(getattr(library,function)(handle,*args,ctypes.byref(value)));row[name]=value.value
   stream.write(json.dumps(row)+'\n');time.sleep(a.interval)
finally:library.nvmlShutdown()
