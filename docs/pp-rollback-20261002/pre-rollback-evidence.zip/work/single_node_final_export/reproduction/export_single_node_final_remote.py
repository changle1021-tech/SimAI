"""Verify the installed public entrypoint and export auditable single-node evidence."""
import csv, hashlib, json, os, subprocess, tarfile, time
from pathlib import Path

R = Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
P = Path('/home/turbo_ops/changle/SimAI/vidur-alibabacloud')
PY = '/home/turbo_ops/miniconda3/envs/sarathi/bin/python'
deployment = json.loads((R/'single_node_q9_deployment.json').read_text())
if deployment['phase'] != 'complete':
    raise RuntimeError('Installed deployment must finish before export')
env = os.environ.copy()
env.update(PYTHONPATH=str(P), OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
target = P/'benchmark_runs/single_node_pp_fixed_20261001'
with (R/'single_node_public_reference.log').open('x') as log:
    subprocess.run([PY, str(P/'scripts/run_vllm051_profiled_simulation.py'),
                    '--config', str(P/'configs/vllm051_single_node_pp/l2_tp1pp2.json'),
                    '--mode', 'simulate', '--output-dir', str(target)], cwd=P,
                   env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
metrics = Path((target/'run_path.txt').read_text())/'request_metrics.csv'
rows = list(csv.DictReader(metrics.open()))
if len(rows) != 3:
    raise RuntimeError('Public simulation request count changed')
for row in rows:
    if int(float(row['request_num_prefill_tokens'])) != 512 or int(float(row['request_num_decode_tokens'])) != 50:
        raise RuntimeError('Public simulation token shape changed')
reference = dict(output_directory=str(target), metrics_file=str(metrics),
                 requests=rows, mean_e2e_ms=sum(float(r['request_e2e_time'])*1000 for r in rows)/3)
(R/'single_node_public_reference.json').write_text(json.dumps(reference, indent=2))
entries = {}
def add(file, archive_name):
    if not file.is_file():
        raise FileNotFoundError(file)
    entries[archive_name] = file
def tree(directory, archive_name):
    for file in directory.rglob('*'):
        if file.is_file() and '__pycache__' not in file.parts:
            if file.suffix in ('.py', '.json', '.csv', '.log', '.txt', '.md'):
                add(file, archive_name+'/'+str(file.relative_to(directory)))

for file in (R/'staging/vidur').rglob('*.py'):
    add(P/file.relative_to(R/'staging'), 'repo/'+str(file.relative_to(R/'staging')))
for directory in ['tests', 'configs/vllm051_single_node_pp',
                  'data/profiling/vllm051_single_node_pp_20261001']:
    tree(P/directory, 'repo/'+directory)
for name in ['run_vllm051_profiled_simulation.py', 'profile_native_decoder_graph_vllm051.py']:
    add(P/'scripts'/name, 'repo/scripts/'+name)
for name in ['single_node_q9_deployment.json', 'single_node_q9_deployed_tests.log',
             'single_node_q9_cpu_cli_help.log', 'single_node_corrected_q9_state.json',
             'single_node_corrected_q9_manifest.json', 'single_node_frozen_holdout_q8_state.json',
             'single_node_frozen_holdout_q8_manifest.json', 'single_node_public_reference.json',
             'single_node_public_reference.log', 'native_decoder_graph_tp_group_q8.csv']:
    add(R/name, 'evidence/'+name)
tree(target, 'evidence/public_reference')
public_config = json.loads((P/'configs/vllm051_single_node_pp/l2_tp1pp2.json').read_text())
add(Path(public_config['request_generator_config']['trace_file']), 'evidence/public_reference/original_arrival_trace.csv')
state = json.loads((R/'single_node_corrected_q9_state.json').read_text())
for case in state['completed']:
    a = case['arguments']
    for index in range(10):
        native = R/(a['case_prefix']+'_'+str(index))
        for name in ['vllm.json', 'arrival_trace.csv']:
            add(native/name, 'evidence/native/'+native.name+'/'+name)
        for name in ['client_launch.json', 'server_launch.json', 'native_metadata.json']:
            if (native/name).exists():
                add(native/name, 'evidence/native/'+native.name+'/'+name)
        deployed = R/(a['label']+'_deployed_final_'+str(index))
        run = Path((deployed/'run_path.txt').read_text())
        for name in ['request_metrics.csv', 'config.json']:
            if (run/name).exists():
                add(run/name, 'evidence/replay/'+deployed.name+'/'+name)
    stem = Path(a['cpu']).stem
    for audit_dir in R.glob(stem+'.http_profile.*'):
        if (audit_dir/'primitives.audit.json').exists():
            tree(audit_dir, 'evidence/cpu/'+audit_dir.name)
for directory in ['engine_observer_tp2pp2_aba_q8']:
    if (R/directory).exists():
        tree(R/directory, 'evidence/diagnosis/'+directory)
for pattern in ['single_node*_state.json', '*_comparison.json']:
    for file in R.glob(pattern):
        add(file, 'evidence/history/'+file.name)
tree(R/'single_node_q9_deploy_backup', 'backup')
for file in (R/'staging').glob('*.py'):
    add(file, 'reproduction/'+file.name)
for name in ['run_single_node_frozen_holdout_q8.py', 'run_single_node_q9_replay_remote.py',
             'finalize_single_node_q9_deployment_remote.py', 'export_single_node_final_remote.py']:
    if (R/name).exists():
        add(R/name, 'reproduction/'+name)
manifest = {name: dict(sha256=hashlib.sha256(file.read_bytes()).hexdigest(), size=file.stat().st_size)
            for name, file in sorted(entries.items())}
(R/'single_node_final_bundle_manifest.json').write_text(json.dumps(manifest, indent=2))
add(R/'single_node_final_bundle_manifest.json', 'SHA256_manifest.json')
output = R/'single_node_pp_final_20261001.tar.gz'
with tarfile.open(output, 'x:gz') as tar:
    for name, file in sorted(entries.items()):
        tar.add(file, arcname=name, recursive=False)
print(json.dumps(dict(phase='complete', archive=str(output), files=len(entries),
                      bytes=output.stat().st_size, public_mean_e2e_ms=reference['mean_e2e_ms']), indent=2), flush=True)
