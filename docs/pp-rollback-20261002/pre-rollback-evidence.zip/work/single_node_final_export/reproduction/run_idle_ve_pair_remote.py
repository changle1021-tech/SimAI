import json,os,subprocess,time
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');s=dict(pid=os.getpid(),phase='native',started_at_epoch=time.time())
def save():(R/'idle_ve_pair_state.json').write_text(json.dumps(s))
save()
try:
 for mode in ['native','control']:
  s['phase']=mode;save()
  with (R/f'idle_ve_{mode}_runner.log').open('w') as f:
   subprocess.run(['python3',str(R/f'staging/run_idle_ve_{mode}_remote.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
 s['phase']='complete';save()
except Exception as e:s.update(phase='failed',error=repr(e));save();raise
