import csv,json,os,shutil,subprocess,time,statistics
from pathlib import Path
import argparse
p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('--case-prefix',required=True);p.add_argument('--cpu',required=True);p.add_argument('--model',default='meta-llama/Llama-2-7b-hf');p.add_argument('--tp',type=int,default=1);p.add_argument('--pp',type=int,default=2);p.add_argument('--rank-map',default='[0,0]');p.add_argument('--loop',default='serving');p.add_argument('--transport');p.add_argument('--all-reduce');p.add_argument('--llama3',action='store_true');p.add_argument('--decoder-graph');p.add_argument('--rounds',type=int,default=3);a=p.parse_args()
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');P=Path('/home/turbo_ops/changle/SimAI/vidur-alibabacloud');PY='/home/turbo_ops/miniconda3/envs/sarathi/bin/python';s=dict(pid=os.getpid(),phase='running',started_at_epoch=time.time(),arguments=vars(a))
def save():(R/f'{a.label}_replay_state.json').write_text(json.dumps(s))
save()
try:
 assert json.loads((R/'overlay_state.json').read_text())['phase']=='complete'
 config=json.loads((P/'benchmark_runs/2026-09-30_16-40-22-022292/config.json').read_text())
 stem='llama3' if a.llama3 else None
 config['execution_time_predictor_config'].update(num_training_job_threads=4,compute_input_file=str(R/('llama3_mlp.csv' if a.llama3 else 'mlp_native_operators.csv')),attention_input_file=str(R/('llama3_attention.csv' if a.llama3 else 'attention_physical_layout.csv')),cpu_overhead_input_file=str(R/a.cpu),cuda_graph_max_seq_len=4096,decode_attention_execution_mode='cuda_graph',execution_loop_mode=a.loop,decoder_graph_input_file=str(R/(a.decoder_graph or ('llama3_decoder.csv' if a.llama3 else 'native_decoder_graph.csv'))),network_transport=a.transport)
 if a.all_reduce:config['execution_time_predictor_config']['all_reduce_input_file']=str(R/a.all_reduce)
 config['cluster_config']['replica_config'].update(model_name=a.model,tensor_parallel_size=a.tp,num_pipeline_stages=a.pp,rank_node_map=a.rank_map,expert_model_parallel_size=1)
 conf=R/f'{a.label}_config.json';conf.write_text(json.dumps(config,indent=2));env=os.environ.copy();env.update(PYTHONPATH=str(R/'overlay'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
 actual=[];pred=[];rounds=[]
 for i in range(a.rounds):
  s['round']=i;save();case=R/f'{a.case_prefix}_{i}';out=case/a.label
  with (case/f'{a.label}.log').open('w') as log:subprocess.run([PY,str(R/'staging/scripts/vidur_decode_diagnostic.py'),'--config',str(conf),'--mode','replay','--trace',str(case/'arrival_trace.csv'),'--output-dir',str(out)],cwd=P,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  run=Path((out/'run_path.txt').read_text().strip())
  for n in ['request_metrics.csv','batch_metrics.csv','config.json']:shutil.copy2(run/n,out/n)
  values=[float(x['request_e2e_time'])*1000 for x in csv.DictReader((out/'request_metrics.csv').open())];v=json.loads((case/'vllm.json').read_text());m=v['summary']['e2e_ms']['mean'];actual.append(m);pred.extend(values);rounds.append(dict(round=i,actual_e2e_mean_ms=m,predicted_e2e_mean_ms=statistics.mean(values),error_pct=100*(statistics.mean(values)/m-1)))
  print(a.label,i,rounds[-1],flush=True)
 result=dict(arguments=vars(a),rounds=rounds,actual_mean_ms=statistics.mean(actual),predicted_mean_ms=statistics.mean(pred),signed_error_pct=100*(statistics.mean(pred)/statistics.mean(actual)-1),success_threshold_pct=10)
 (R/f'{a.label}_comparison.json').write_text(json.dumps(result,indent=2));s['phase']='complete';save()
except Exception as e:s.update(phase='failed',error=repr(e));save();raise
