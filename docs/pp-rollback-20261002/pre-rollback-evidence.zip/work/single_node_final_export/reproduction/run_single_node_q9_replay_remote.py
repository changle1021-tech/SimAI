import json,time,subprocess,shutil,hashlib,os
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
PY='/home/turbo_ops/miniconda3/envs/sarathi/bin/python'
STATE=R/'single_node_corrected_q9_state.json'
if STATE.exists():raise FileExistsError('Preserve old replay results')
state=dict(pid=os.getpid(),phase='wait_frozen_q8',started_at=time.time(),completed=[])
def save():STATE.write_text(json.dumps(state,indent=2))
def run(command,label):
 state['phase']=label;save()
 with (R/(label+'.log')).open('x') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('COMPLETE',label,flush=True)
save()
try:
 deadline=time.monotonic()+1800
 while True:
  source=json.loads((R/'single_node_frozen_holdout_q8_state.json').read_text())
  if source['phase']=='failed':raise RuntimeError('Frozen native evaluation failed')
  if source['phase']=='complete':break
  if time.monotonic()>deadline:raise TimeoutError('Native holdouts have not completed')
  time.sleep(5)
 if len(source['completed'])!=4:raise RuntimeError('Incomplete frozen native references')
 for path,sha in json.loads((R/'single_node_frozen_holdout_q8_manifest.json').read_text()).items():
  if hashlib.sha256((R/path).read_bytes()).hexdigest()!=sha:raise RuntimeError('Q8 source changed before snapshot')
 shutil.copytree(R/'staging',R/'q8_frozen_source_snapshot',ignore=shutil.ignore_patterns('__pycache__'))
 shutil.copy2(R/'overlay_tests_retry.log',R/'q8_frozen_source_snapshot/overlay_tests.log')
 for file in (R/'q9_pending/staging').rglob('*.py'):
  target=R/'staging'/file.relative_to(R/'q9_pending/staging');shutil.copy2(file,target)
 files=list((R/'staging/vidur').rglob('*.py'))
 manifest={str(f.relative_to(R)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
 (R/'single_node_corrected_q9_manifest.json').write_text(json.dumps(manifest,indent=2))
 state['changes']='Count the embedding reduction outside the combined decoder DAG; ship the exact small-event-pool collector used to produce q7 profiles. Physical primitive values unchanged.';save()
 run([PY,str(R/'staging/repair_overlay_remote.py')],'q9_overlay_gate')
 for result in source['completed']:
  a=result['arguments'];label=a['label'].replace('q8_holdout_','q9_corrected_')
  command=[PY,str(R/'staging/replay_validation_matrix_remote.py'),'--label',label,'--case-prefix',a['case_prefix'],'--cpu',a['cpu'],'--model',a['model'],'--tp',str(a['tp']),'--pp',str(a['pp']),'--rank-map',a['rank_map'],'--loop',a['loop'],'--all-reduce',a['all_reduce'],'--rounds',str(a['rounds'])]
  if a['llama3']:command.append('--llama3')
  else:command+=['--decoder-graph',a['decoder_graph']]
  run(command,label+'_replay')
  out=json.loads((R/(label+'_comparison.json')).read_text())
  state['completed'].append(out);save()
 for path,sha in manifest.items():
  if hashlib.sha256((R/path).read_bytes()).hexdigest()!=sha:raise RuntimeError('Q9 source changed during replay')
 state.update(phase='complete',mean_e2e_pass=all(abs(x['signed_error_pct'])<=10 for x in state['completed']),completed_at=time.time());save()
except Exception as error:
 state.update(phase='failed',error=repr(error));save();raise
