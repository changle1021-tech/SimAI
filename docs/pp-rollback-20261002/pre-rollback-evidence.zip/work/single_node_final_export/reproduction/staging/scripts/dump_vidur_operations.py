import argparse,json,statistics
from pathlib import Path
from vidur_decode_diagnostic import restore_config
from vidur.entities import Batch, Request
from vidur.entities.request import RequestType
from vidur.execution_time_predictor import ExecutionTimePredictorRegistry
p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--output',required=True);a=p.parse_args()
saved=json.loads(Path(a.config).read_text());saved['execution_time_predictor_config']['num_training_job_threads']=4
config=restore_config(saved,Path(a.output).parent/'op_config'); r=config.cluster_config.replica_config;s=config.cluster_config.replica_scheduler_config;e=config.execution_time_predictor_config
pred=ExecutionTimePredictorRegistry.get(e.get_type(),predictor_config=e,replica_config=r,replica_scheduler_config=s,metrics_config=config.metrics_config,simulation_config=config)
rows=[]
for phase in ['prefill','decode']:
 for step in ([0] if phase=='prefill' else range(1,50)):
  req=Request(0,512,50,num_processed_tokens=0 if phase=='prefill' else 512+step)
  if phase=='decode':req._is_prefill_complete=True;req.request_type=RequestType.DECODE
  batch=Batch(0,[req],[512 if phase=='prefill' else 1]);stages=[]
  for st in range(r.num_pipeline_stages):
   t=pred.get_execution_time(batch,st)
   stages.append(dict(stage=st,model_ms=t.model_time_ms,total_ms=t.total_time*1000,block_ms=t._get_block_execution_time(),values={k:v for k,v in vars(t).items() if isinstance(v,(float,int))}))
  rows.append(dict(phase=phase,step=step,rounded_tokens=batch._total_num_tokens_rounded,stages=stages))
Path(a.output).write_text(json.dumps(rows,indent=2))
print('OPERATIONS_DUMPED',a.output,flush=True)
