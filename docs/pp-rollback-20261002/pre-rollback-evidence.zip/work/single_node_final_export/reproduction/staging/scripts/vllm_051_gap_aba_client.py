"""Within-engine workload/control experiment; raw primitives, never a fit target."""
import argparse,asyncio,json,time
from pathlib import Path
import aiohttp

p=argparse.ArgumentParser()
p.add_argument('--output',required=True)
p.add_argument('--repetitions',type=int,default=5)
a=p.parse_args()

async def main():
    results=[]
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=120)) as session:
        async def control(endpoint,**params):
            params={key:str(value).lower() if isinstance(value,bool) else value
                    for key,value in params.items()}
            async with session.post('http://127.0.0.1:8089/diagnostic/profile/'+endpoint,params=params) as response:
                if response.status!=200:raise RuntimeError(await response.text())
                return await response.json()
        async def request():
            payload=dict(model='vidur-profile-model',prompt=[1]+[42]*511,max_tokens=50,
                ignore_eos=True,temperature=0,stream=True,
                stream_options=dict(include_usage=True,continuous_usage_stats=True))
            start=time.perf_counter();usage=None
            async with session.post('http://127.0.0.1:8089/v1/completions',json=payload) as response:
                if response.status!=200:raise RuntimeError(await response.text())
                async for line in response.content:
                    if line.startswith(b'data: ') and line.strip()!=b'data: [DONE]':
                        event=json.loads(line[6:])
                        if event.get('usage'):usage=event['usage']
            if not usage or usage['prompt_tokens']!=512 or usage['completion_tokens']!=50:
                raise RuntimeError(f'Invalid tokens: {usage}')
            return (time.perf_counter()-start)*1000
        # AsyncLLMEngine starts its background loop on the first request.
        # Establish an idle boundary before the first diagnostic control call.
        for _ in range(3):await request()
        await control('audit',label='initial_warm')
        plans=[('natural_hot_a',0,False),('natural_idle',10,False),
            ('natural_hot_b',0,False),('filtered_idle',10,True),
            ('filtered_hot',0,True),('natural_hot_c',0,False)]
        for label,idle_seconds,filtered in plans:
            await control('wait_control',active=filtered)
            for _ in range(3):await request()
            await control('audit',label='warm_'+label)
            await control('start')
            elapsed=[]
            for _ in range(a.repetitions):
                if idle_seconds:await asyncio.sleep(idle_seconds)
                elapsed.append(await request())
            state=await control('collect',label=label)
            results.append(dict(label=label,idle_after_response_seconds=idle_seconds,
                active_ve_wait_control=filtered,e2e_ms=elapsed,collection=state))
            Path(a.output).write_text(json.dumps(results,indent=2))
            print('ABA_PHASE',json.dumps(results[-1]),flush=True)
asyncio.run(main())
