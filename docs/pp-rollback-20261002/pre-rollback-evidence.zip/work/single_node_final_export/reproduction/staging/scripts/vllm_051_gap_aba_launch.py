"""Own diagnostic server and client only, no installed vLLM modifications."""
import argparse,json,os,signal,socket,subprocess,time,urllib.request
from pathlib import Path
from types import SimpleNamespace
from http_profile_arguments import server_arguments

p=argparse.ArgumentParser()
p.add_argument('--output-dir',required=True)
p.add_argument('--model',default='/mnt/data02/000000/model/Llama-2-7b-hf-bin-export')
p.add_argument('--tp',type=int,default=1)
p.add_argument('--pp',type=int,default=2)
p.add_argument('--repetitions',type=int,default=5)
p.add_argument('--seed',type=int,default=36)
p.add_argument('--gpu-memory-utilization',type=float,default=0.8)
options=p.parse_args()
if min(options.tp,options.pp,options.repetitions)<1:
 raise ValueError('Parallelism and repetitions must be positive')
if not 0<options.gpu_memory_utilization<1:
 raise ValueError('GPU memory utilization must be in (0,1)')
with socket.socket() as port_check:
 port_check.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
 port_check.bind(('127.0.0.1',8089))
root=Path(options.output_dir);root.mkdir(exist_ok=False)
(root/'diagnostic_arguments.json').write_text(json.dumps(vars(options),indent=2))
source=Path('/diagnostic/staging/vidur/profiling/cpu_overhead')
original=(source/'vllm_051_http_profile_server.py').read_text()
insertion='''
# Diagnostic toggle at an idle request boundary; no change to installed files.
import inspect,textwrap
from importlib.metadata import version
if version('vllm').split('+')[0]!='0.5.1':
 raise RuntimeError('Diagnostic wait control targets vLLM 0.5.1')
wait_control_active=False
wait_counts=dict(calls=0,mixed=0)
native_asyncio_wait=asyncio.wait
async def diagnostic_wait(tasks,*args,**kwargs):
 global wait_counts
 tasks=list(tasks)
 completed=sum(task.done() for task in tasks)
 wait_counts['calls']+=1
 wait_counts['mixed']+=int(0<completed<len(tasks))
 if wait_control_active and 0<completed<len(tasks):
  tasks=[task for task in tasks if not task.done()]
 return await native_asyncio_wait(tasks,*args,**kwargs)
# Restrict the diagnostic to the engine loop; other asyncio users retain their
# original task semantics. Copy the original loop rather than reimplement it.
loop_source=textwrap.dedent(inspect.getsource(AsyncLLMEngine.run_engine_loop))
if loop_source.count('await asyncio.wait(')!=1:
 raise RuntimeError('Unexpected engine wait implementation')
loop_source=loop_source.replace('await asyncio.wait(','await diagnostic_wait(',1)
loop_context=dict(AsyncLLMEngine.run_engine_loop.__globals__)
loop_context['diagnostic_wait']=diagnostic_wait
exec(compile(loop_source,'<diagnostic engine wait>','exec'),loop_context)
AsyncLLMEngine.run_engine_loop=loop_context['run_engine_loop']
async def change_wait_control(active:bool):
 global wait_control_active,wait_counts
 await idle.wait()
 wait_control_active=active
 wait_counts=dict(calls=0,mixed=0)
 return dict(active=active)
'''
def replace_once(text,old,new):
 if text.count(old)!=1:raise RuntimeError(f'Unexpected diagnostic source: {old}')
 return text.replace(old,new,1)
original=replace_once(original,'original_init=FastAPI.__init__',insertion+'\noriginal_init=FastAPI.__init__')
original=replace_once(original,"self.add_api_route('/diagnostic/profile/start'","self.add_api_route('/diagnostic/profile/wait_control',change_wait_control,methods=['POST'])\n self.add_api_route('/diagnostic/profile/start'")
original=replace_once(original,'worker_rows=workers,environment=environment,observations=list(observations)',
    'worker_rows=workers,environment=environment,observations=list(observations),wait_counts=dict(wait_counts),wait_control_active=wait_control_active')
original=replace_once(original,'steps.clear();last_step.clear()','steps.clear();last_step.clear();wait_counts.update(calls=0,mixed=0)')
script=root/'server.py';script.write_text(original)
args=SimpleNamespace(model=options.model,tokenizer=None,
    revision=None,tokenizer_revision=None,dtype='float16',load_format='auto',seed=options.seed,
    max_model_len=4096,tensor_parallel_size=options.tp,pipeline_parallel_size=options.pp,max_num_seqs=8,
    max_num_batched_tokens=4096,gpu_memory_utilization=options.gpu_memory_utilization,enforce_eager=False,trust_remote_code=False)
command=server_arguments(args,script,root/'driver')
(root/'server_launch.json').write_text(json.dumps(command,indent=2))
environment=os.environ.copy();environment['PYTHONPATH']=str(source)+os.pathsep+environment.get('PYTHONPATH','')
log=(root/'server.log').open('w');server=subprocess.Popen(command,env=environment,stdout=log,stderr=subprocess.STDOUT)
try:
 for _ in range(180):
  if server.poll() is not None:raise RuntimeError('Server exited; see server.log')
  try:
   with urllib.request.urlopen('http://127.0.0.1:8089/health',timeout=1):break
  except Exception:time.sleep(1)
 else:raise RuntimeError('Server health timeout')
 client=['python3','/diagnostic/staging/scripts/vllm_051_gap_aba_client.py','--output',str(root/'audit.json'),
         '--repetitions',str(options.repetitions)]
 with (root/'client.log').open('w') as stream:
  subprocess.run(client,env=environment,stdout=stream,stderr=subprocess.STDOUT,check=True)
 (root/'complete.json').write_text(json.dumps(dict(completed_at=time.time())))
finally:
 if server.poll() is None:
  server.send_signal(signal.SIGTERM)
  try:server.wait(timeout=30)
  except subprocess.TimeoutExpired:server.kill();server.wait(timeout=10)
 log.close()
