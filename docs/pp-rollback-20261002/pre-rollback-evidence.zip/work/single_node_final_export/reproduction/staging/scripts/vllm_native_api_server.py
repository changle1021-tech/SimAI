"""Record this process identity, then start the unmodified vLLM API service."""
import json, os, runpy, sys
from importlib.metadata import version
from pathlib import Path

index=sys.argv.index('--diagnostic-output')
output=Path(sys.argv[index+1]);del sys.argv[index:index+2]
output.mkdir(parents=True,exist_ok=False)
(output/'server_pid.txt').write_text(str(os.getpid()))
(output/'provenance.json').write_text(json.dumps(dict(
    argv=sys.argv,versions={k:version(k) for k in ('vllm','torch','ray')},
    measurement='Unmodified vLLM API: no engine/worker patches, profiling hooks or wait control'),indent=2))
runpy.run_module('vllm.entrypoints.openai.api_server',run_name='__main__')
