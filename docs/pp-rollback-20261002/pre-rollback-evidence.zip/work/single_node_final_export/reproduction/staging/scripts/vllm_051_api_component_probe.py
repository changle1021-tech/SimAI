"""Diagnostic API serving path; collect named regions without per-step CUDA waits."""
import atexit,contextvars,json,os,runpy,sys,time
from pathlib import Path
from collections import defaultdict
idx=sys.argv.index('--diagnostic-output');OUT=Path(sys.argv[idx+1]);del sys.argv[idx:idx+2]
OUT.mkdir(parents=True,exist_ok=False);(OUT/'server_pid.txt').write_text(str(os.getpid()))
from pp_profile_contract import request_key,aggregate_step
from vllm_051_pp_cpu_profile import ProfilingRayExecutor
import vllm.executor.ray_gpu_executor as raymodule
from vllm.engine.async_llm_engine import _AsyncLLMEngine,AsyncLLMEngine
from vllm.core.scheduler import Scheduler
from fastapi import FastAPI
executors=[];steps=[];current=contextvars.ContextVar('api_component_step',default=None);enabled=False
class DiagnosticExecutor(ProfilingRayExecutor):
 def __init__(self,*a,**kw):
  super().__init__(*a,**kw);executors.append(self)
 async def execute_model_async(self,req):
  begin=time.perf_counter_ns();result=await super().execute_model_async(req)
  row=current.get()
  if row is not None and req and req.seq_group_metadata_list:
   row.update(key=request_key(req),executor_ms=(time.perf_counter_ns()-begin)/1e6)
  return result
raymodule.RayGPUExecutorAsync=DiagnosticExecutor
original_schedule=Scheduler.schedule
original_process=_AsyncLLMEngine._process_model_outputs
original_step=_AsyncLLMEngine.step_async

def schedule(self,*a,**kw):
 begin=time.perf_counter_ns();result=original_schedule(self,*a,**kw);end=time.perf_counter_ns();row=current.get()
 if row is not None:
  metadata,scheduled=result
  if metadata:
   row.update(schedule_ms=(end-begin)/1e6,phase='prefill' if metadata[0].is_prompt else 'decode',
    batch_size=len(metadata),prefill_tokens_per_request=sum(m.token_chunk_size for m in metadata)/len(metadata) if metadata[0].is_prompt else 0,
    request_ids=[m.request_id for m in metadata])
 return result

def process(self,*a,**kw):
 begin=time.perf_counter_ns();result=original_process(self,*a,**kw);row=current.get()
 if row is not None:row['process_outputs_ms']=(time.perf_counter_ns()-begin)/1e6
 return result

async def step(self,ve):
 if not enabled:return await original_step(self,ve)
 row=dict(virtual_engine=ve);token=current.set(row);start=time.perf_counter_ns()
 try:result=await original_step(self,ve)
 finally:current.reset(token)
 end=time.perf_counter_ns();row.update(start_ns=start,end_ns=end,engine_step_ms=(end-start)/1e6)
 if 'key' in row:
  row['engine_bookkeeping_ms']=row['engine_step_ms']-sum(row[k] for k in ['schedule_ms','executor_ms','process_outputs_ms']);steps.append(row)
 return result
Scheduler.schedule=schedule;_AsyncLLMEngine._process_model_outputs=process;_AsyncLLMEngine.step_async=step

def persist(collect_workers=False):
 payload=dict(steps=steps,measurement='named regions in actual streaming API; no per-step CUDA synchronization')
 if collect_workers:
  ex=executors[-1];workers=ex._run_workers('pp_profile_get_records');environment=ex._run_workers('pp_profile_environment')
  (OUT/'worker_records.json').write_text(json.dumps(dict(workers=workers,environment=environment),indent=2))
  by_key=defaultdict(list)
  for rank_rows in workers:
   for r in rank_rows:by_key[r['key']].append(r)
  tp=ex.parallel_config.tensor_parallel_size;pp=ex.parallel_config.pipeline_parallel_size
  aggregates=[]
  for s in steps:
   timing=aggregate_step(s,by_key.pop(s['key']),tp,pp);aggregates.append(dict(s,**timing))
  if by_key:raise RuntimeError('Unmatched GPU records')
  payload.update(worker_rows=workers,environment=environment,aggregates=aggregates)
 (OUT/'components.json').write_text(json.dumps(payload,indent=2));return dict(steps=len(steps),collected_workers=collect_workers)
async def start_profile():
 global enabled
 if enabled:raise RuntimeError('Already profiling')
 steps.clear();executors[-1]._run_workers('pp_profile_set_enabled',True);enabled=True
 return dict(profiling=True)
async def collect_profile():
 global enabled
 enabled=False
 return persist(True)
original_init=FastAPI.__init__
def app_init(self,*a,**kw):
 original_init(self,*a,**kw)
 self.add_api_route('/diagnostic/profile/start',start_profile,methods=['POST'])
 self.add_api_route('/diagnostic/profile/collect',collect_profile,methods=['POST'])
FastAPI.__init__=app_init
atexit.register(lambda:persist(False) if not (OUT/'components.json').exists() else None)
runpy.run_module('vllm.entrypoints.openai.api_server',run_name='__main__')
