import hashlib,json,shutil,time
from pathlib import Path
src=Path('/mnt/data02/000000/model/Meta-Llama-3-8B-Instruct');dst=Path('/diagnostic/llama3_local');dst.mkdir(exist_ok=False)
manifest=[]
for f in sorted(src.iterdir()):
 if not f.is_file():continue
 digest=hashlib.sha256();out=dst/f.name
 with f.open('rb') as incoming,out.open('xb') as outgoing:
  while chunk:=incoming.read(16*1024*1024):outgoing.write(chunk);digest.update(chunk)
 assert out.stat().st_size==f.stat().st_size
 manifest.append(dict(source=str(f),target=str(out),bytes=out.stat().st_size,sha256=digest.hexdigest()))
 print(f.name,out.stat().st_size,flush=True)
(dst/'copy_provenance.json').write_text(json.dumps(manifest,indent=2))
