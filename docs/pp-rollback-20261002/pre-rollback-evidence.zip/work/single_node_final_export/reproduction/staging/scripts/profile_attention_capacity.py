import json,time,statistics,os
from pathlib import Path
import torch
from vllm_flash_attn import flash_attn_with_kvcache
from vllm import _custom_ops as ops
out=Path('/diagnostic/attention_capacity');out.mkdir(exist_ok=True)
torch.cuda.set_device(0); rows=[]
for context in [512,1024]:
 for layers in [1,16]:
  for capacity in [context+16,4096]:
   blocks=(capacity+15)//16
   key=torch.randn((layers,blocks,16,32,128),device='cuda',dtype=torch.float16)
   val=torch.randn_like(key);q=torch.randn((1,1,32,128),device='cuda',dtype=torch.float16)
   table=torch.arange(blocks,device='cuda',dtype=torch.int32).view(1,-1)
   lens=torch.tensor([context+1],device='cuda',dtype=torch.int32)
   def run():
    for j in range(layers):
     flash_attn_with_kvcache(q,key[j],val[j],block_table=table,cache_seqlens=lens,softmax_scale=128**-0.5,causal=True)
   with torch.inference_mode():
    for _ in range(10): run()
    torch.cuda.synchronize()
    g=torch.cuda.CUDAGraph()
    with torch.cuda.graph(g):run()
    for _ in range(10):g.replay()
    torch.cuda.synchronize()
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CUDA]) as prof:
     for _ in range(50):g.replay()
    torch.cuda.synchronize()
    path=out/f'context{context}_layers{layers}_cap{capacity}.trace.json';prof.export_chrome_trace(str(path))
    gpu=[e for e in json.loads(path.read_text())['traceEvents'] if e.get('cat')=='kernel' and e.get('ph')=='X']
    names={}
    for e in gpu:names[e['name']]=names.get(e['name'],0)+e.get('dur',0)/1000/50/layers
    row=dict(context=context,layers=layers,capacity=capacity,block_table_width=blocks,kernel_ms_per_attention=sum(names.values()),kernels_ms=names)
    rows.append(row);print('CAPACITY_RESULT',json.dumps(row),flush=True)
   del g,key,val,q,table,lens;torch.cuda.empty_cache()
(out/'results.json').write_text(json.dumps(rows,indent=2))
