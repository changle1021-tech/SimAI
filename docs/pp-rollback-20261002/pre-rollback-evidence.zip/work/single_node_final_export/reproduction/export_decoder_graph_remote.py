import csv,json,hashlib
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');raw=[R/'native_decoder_graph_full.csv']
if (R/'native_decoder_graph_padding.csv').exists():raw.append(R/'native_decoder_graph_padding.csv')
rows=[]
for path in raw:
 for row in csv.DictReader(path.open()):
  assert row['model_path']=='/mnt/data02/000000/model/Llama-2-7b-hf-bin-export'
  row['model_name']='meta-llama/Llama-2-7b-hf';rows.append(row)
fields=list(dict.fromkeys(k for row in rows for k in row))
output=R/'native_decoder_graph.csv';temp=output.with_suffix('.partial')
with temp.open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
temp.replace(output)
(R/'native_decoder_graph.provenance.json').write_text(json.dumps(dict(raw_files=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in raw],rows=len(rows),label='registry identity of the actual profiled Llama-2 configuration; GPU timings are unchanged'),indent=2))
print(len(rows),flush=True)
