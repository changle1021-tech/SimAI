import ast
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
from typing import List, Dict, Any

ROOT=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
STAGE=ROOT/'staging'
REPO=Path('/home/turbo_ops/changle/SimAI/vidur-alibabacloud')
CPU_DIR=Path('/home/turbo_ops/changle/Files/vidur_cpu_overhead')
NAME='vidur-crossnode-residual-20261001'
PY='/home/turbo_ops/miniconda3/envs/sarathi/bin/python'


def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def deploy():
    if json.loads((ROOT/'full_profile_state.json').read_text())['phase']!='complete':
        raise RuntimeError('Full profile is not complete')
    profiles=list(csv.DictReader((ROOT/'pp2_cpu.csv').open()))
    if len(profiles)!=16 or {r['phase'] for r in profiles}!={'prefill','decode'}:
        raise RuntimeError('Incomplete PP2 profile')
    for row in profiles:
        if int(row['pipeline_parallel_degree'])!=2 or int(row['tensor_parallel_degree'])!=1:
            raise RuntimeError('Unexpected parallelism in PP2 profile')
    backup=ROOT/'backups';backup.mkdir(exist_ok=True)
    manifest=json.loads((STAGE/'deploy_manifest.json').read_text())
    target=REPO/'vidur/execution_time_predictor/sklearn_execution_time_predictor.py'
    if digest(target) not in [manifest['predictor_original_sha256'], digest(STAGE/'vidur/execution_time_predictor/sklearn_execution_time_predictor.py')]:
        raise RuntimeError('Predictor changed since inspection; refusing to overwrite other work')
    profiler=CPU_DIR/'vllm_051_cpu_overhead.py'
    if digest(profiler) not in [manifest['cpu_profiler_original_sha256'], digest(STAGE/'vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py')]:
        raise RuntimeError('CPU profiler changed since inspection')
    for source,name,expected in [
        (target,'sklearn_execution_time_predictor.py',manifest['predictor_original_sha256']),
        (profiler,'vllm_051_cpu_overhead.py',manifest['cpu_profiler_original_sha256'])]:
        if not (backup/name).exists():shutil.copy2(source,backup/name)
        if digest(backup/name)!=expected:raise RuntimeError('Original backup does not match inspected source')
    if not (backup/'cpu_overheads.csv').exists():
        shutil.copy2(CPU_DIR/'cpu_overheads.csv',backup/'cpu_overheads.csv')
    shutil.copy2(target.with_name('base_execution_time_predictor.py'),backup/'base_execution_time_predictor.py')
    shutil.copy2(STAGE/'vidur/execution_time_predictor/sklearn_execution_time_predictor.py',target)
    for p in (STAGE/'vidur/profiling/cpu_overhead').glob('*.py'):
        shutil.copy2(p,REPO/'vidur/profiling/cpu_overhead'/p.name)
        subprocess.run(['sudo','-n','cp',str(p),str(CPU_DIR/p.name)],check=True)
    for p in (STAGE/'tests').glob('test_pp*.py'):
        shutil.copy2(p,REPO/'tests'/p.name)
    shutil.copy2(STAGE/'docs/pp_cpu_profiling.md',REPO/'docs/pp_cpu_profiling.md')
    subprocess.run(['sudo','-n','docker','exec','vllm051','mkdir','-p',
                    '/vllm-workspace/vidur_cpu_overhead'],check=True)
    for p in (STAGE/'vidur/profiling/cpu_overhead').glob('*.py'):
        subprocess.run(['sudo','-n','docker','cp',str(p),
                        'vllm051:/vllm-workspace/vidur_cpu_overhead/'+p.name],check=True)
    # Use the same CSV writer as the CLI; migrate only the legacy PP dimension.
    source=STAGE/'vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py'
    node=next(n for n in ast.parse(source.read_text()).body
              if isinstance(n,ast.FunctionDef) and n.name=='_write_rows')
    env=dict(Path=Path,List=List,Dict=Dict,Any=Any,csv=csv)
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),env)
    merged_path=ROOT/'merged_cpu_overheads.csv'
    shutil.copy2(backup/'cpu_overheads.csv',merged_path)
    env['_write_rows'](merged_path,profiles,True)
    subprocess.run(['sudo','-n','cp',str(merged_path),str(CPU_DIR/'cpu_overheads.csv')],check=True)
    merged=list(csv.DictReader((CPU_DIR/'cpu_overheads.csv').open()))
    old=list(csv.DictReader((backup/'cpu_overheads.csv').open()))
    if len(merged)!=len(old)+16:raise RuntimeError('CPU merge count mismatch')
    for before,after in zip(old,merged):
        if any(after[k]!=v for k,v in before.items()):raise RuntimeError('Legacy CPU labels changed')
    (ROOT/'deployment.json').write_text(json.dumps(dict(
        cpu_csv=str(CPU_DIR/'cpu_overheads.csv'),cpu_csv_sha256=digest(CPU_DIR/'cpu_overheads.csv'),
        predictor_sha256=digest(target),legacy_rows=len(old),new_pp2_rows=16,
        backups=str(backup)),indent=2))
    with (ROOT/'tests.log').open('w') as stream:
        subprocess.run([PY,'-m','unittest','discover','-s','tests','-p','test_*.py','-v'],
                       cwd=REPO,stdout=stream,stderr=subprocess.STDOUT,check=True)


def replay(state,save):
    state['phase']='vidur_replays';save()
    saved=json.loads((REPO/'benchmark_runs/2026-09-30_16-40-22-022292/config.json').read_text())
    saved['execution_time_predictor_config'].update(
        num_training_job_threads=4,
        compute_input_file=str(ROOT/'mlp_native_operators.csv'),
        attention_input_file=str(ROOT/'attention_physical_layout.csv'),
        cpu_overhead_input_file=str(ROOT/'cpu_crossnode.csv'),
        cuda_graph_max_seq_len=4096, decode_attention_execution_mode='cuda_graph')
    saved['cluster_config']['replica_config']['rank_node_map']='[0,1]' 
    (ROOT/'crossnode_config.json').write_text(json.dumps(saved,indent=2))
    environment=os.environ.copy();environment.update(PYTHONPATH=str(ROOT/'overlay'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    for run in range(3):
        case=ROOT/f'crossnode_holdout_{run}'
        args=[PY,str(STAGE/'scripts/vidur_decode_diagnostic.py'),
              '--config',str(ROOT/'crossnode_config.json'),'--mode','replay',
              '--trace',str(case/'arrival_trace.csv'),'--output-dir',str(case/'vidur')]
        with (case/'vidur.log').open('w') as f:
            subprocess.run(args,cwd=REPO,env=environment,stdout=f,stderr=subprocess.STDOUT,check=True)
        run_path=Path((case/'vidur/run_path.txt').read_text().strip())
        for name in ['request_metrics.csv','batch_metrics.csv','config.json']:
            shutil.copy2(run_path/name,case/'vidur'/name)
        print('REPLAY_DONE',run,run_path,flush=True)
    # Container is retained for subsequent tests.


def main():
    state=dict(pid=os.getpid(),phase='deploying',started_at_epoch=time.time())
    def save():(ROOT/'crossnode_evaluation_state.json').write_text(json.dumps(state))
    save()
    try:
        assert json.loads((ROOT/'overlay_state.json').read_text())['phase']=='complete'
        replay(state,save)
        state['phase']='complete';save()
    except Exception as e:
        state.update(phase='failed',error=repr(e));save();raise


if __name__=='__main__':main()
