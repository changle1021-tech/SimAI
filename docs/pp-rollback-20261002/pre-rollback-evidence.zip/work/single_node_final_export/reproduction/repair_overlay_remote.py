import json,os,shutil,subprocess,time
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');S=R/'staging';P=Path('/home/turbo_ops/changle/SimAI/vidur-alibabacloud');O=R/'overlay'
state=dict(pid=os.getpid(),phase='testing',started_at_epoch=time.time())
def save():(R/'overlay_state.json').write_text(json.dumps(state))
try:
 for base in ['vidur','tests','scripts']:
  for f in (S/base).rglob('*.py'):
   target=O/f.relative_to(S);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
 if not (O/'data').exists():(O/'data').symlink_to(P/'data',target_is_directory=True)
 save()
 env=os.environ.copy();env['PYTHONPATH']=str(O)
 with (R/'overlay_tests_retry.log').open('w') as f:
  subprocess.run(['/home/turbo_ops/miniconda3/envs/sarathi/bin/python','-m','unittest','discover','-s',str(O/'tests'),'-p','test_*.py','-v'],cwd=P,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 state['phase']='complete';save()
except Exception as e:state.update(phase='failed',error=repr(e));save();raise
