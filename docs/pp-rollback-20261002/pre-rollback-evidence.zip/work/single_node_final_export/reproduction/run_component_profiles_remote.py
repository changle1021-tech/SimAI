import json,os,subprocess,time
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');C='vidur-pp2-residual-20261001';O='vidur-operator-residual-20261001'
s=dict(pid=os.getpid(),phase='starting',started_at_epoch=time.time())
def save():(R/'components_state.json').write_text(json.dumps(s))
save();children=[];streams=[]
try:
 m={int(i):int(v) for i,v in (line.split(',') for line in subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used','--format=csv,noheader,nounits'],text=True).splitlines())}
 if any(m[i]>500 for i in [2,3,4,5]):raise RuntimeError('Selected GPUs occupied: '+str(m))
 existing=subprocess.check_output(['sudo','-n','docker','ps','-a','--format','{{.Names}}'],text=True).splitlines()
 if O in existing:raise RuntimeError('Operator container already exists; inspect before starting')
 subprocess.run(['sudo','-n','docker','run','-d','--name',O,'--gpus','"device=4,5"','--ipc','host','-e','CUDA_VISIBLE_DEVICES=0,1','-e','PYTHONPATH=/diagnostic/staging/vidur/profiling/cpu_overhead','-v','/mnt/data02:/mnt/data02:ro','-v',str(R)+':/diagnostic','--entrypoint','sleep','docker.io/library/vllm:v0.5.1-trace','infinity'],check=True)
 launches={
  'cpu':['sudo','-n','docker','exec',C,'python3','/diagnostic/staging/vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py','--model','/mnt/data02/000000/model/Llama-2-7b-hf-bin-export','--model-name-for-vidur','meta-llama/Llama-2-7b-hf','--tensor-parallel-size','1','--pipeline-parallel-size','2','--executor-backend','ray','--batch-sizes',*map(str,range(1,9)),'--prompt-tokens','512','--decode-tokens','50','--repetitions','5','--warmup-decode-tokens','8','--max-model-len','4096','--max-num-seqs','8','--max-num-batched-tokens','4096','--gpu-memory-utilization','0.2','--load-format','auto','--seed','36','--output','/diagnostic/cpu_complete_regions.csv'],
  'attention':['sudo','-n','docker','exec',O,'python3','/diagnostic/staging/vidur/profiling/cpu_overhead/vllm_051_attention_profile.py','--model','/mnt/data02/000000/model/Llama-2-7b-hf-bin-export','--tensor-parallel-sizes','1','2','--max-model-len','4096','--max-seq-len','4096','--batch-sizes',*map(str,range(1,9)),'--prefill-chunk-sizes','32','64','128','256','512','1024','2048','4096','--kv-cache-sizes',*map(str,[0,64,128,192,256,384,448,512,576,640,768,1024,1536,2048,3072,4032]),'--decode-layout','cuda_graph','--decode-block-table-capacity','4096','--warmup','20','--repetitions','20','--output','/diagnostic/attention_physical_layout.csv']}
 (R/'component_launches.json').write_text(json.dumps(launches,indent=2))
 for name,args in launches.items():
  f=(R/(name+'_component.log')).open('w');streams.append(f);proc=subprocess.Popen(args,stdout=f,stderr=subprocess.STDOUT);children.append(proc);s[name+'_pid']=proc.pid
 s['phase']='profiling';save()
 for child in children:
  if child.wait()!=0:raise RuntimeError('Component profiling child failed: '+str(child.pid))
 s['phase']='complete';save()
except Exception as e:
 s.update(phase='failed',error=repr(e));save();raise
finally:
 for f in streams:f.close()
