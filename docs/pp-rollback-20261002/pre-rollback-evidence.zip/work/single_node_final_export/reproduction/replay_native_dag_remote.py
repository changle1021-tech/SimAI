import json,os,shutil,subprocess,time
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');P=Path('/home/turbo_ops/changle/SimAI/vidur-alibabacloud');PY='/home/turbo_ops/miniconda3/envs/sarathi/bin/python'
s=dict(pid=os.getpid(),phase='running',started_at_epoch=time.time())
def save():(R/'native_dag_replay_state.json').write_text(json.dumps(s))
save()
try:
 assert json.loads((R/'overlay_state.json').read_text())['phase']=='complete'
 base=json.loads((P/'benchmark_runs/2026-09-30_16-40-22-022292/config.json').read_text())
 env=os.environ.copy();env.update(PYTHONPATH=str(R/'overlay'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
 for mode,cpu,nodes in [('local','cpu_serving_loop_full.csv','[0,0]'),('crossnode','cpu_crossnode_serving_loop_full.csv','[0,1]')]:
  config=json.loads(json.dumps(base));config['execution_time_predictor_config'].update(num_training_job_threads=4,compute_input_file=str(R/'mlp_native_operators.csv'),attention_input_file=str(R/'attention_physical_layout.csv'),cpu_overhead_input_file=str(R/cpu),cuda_graph_max_seq_len=4096,decode_attention_execution_mode='cuda_graph',execution_loop_mode='serving',decoder_graph_input_file=str(R/'native_decoder_graph.csv'))
  config['cluster_config']['replica_config']['rank_node_map']=nodes
  conf=R/f'{mode}_native_dag_config.json';conf.write_text(json.dumps(config,indent=2))
  for run in range(3):
   s.update(mode=mode,round=run);save()
   case=R/(f'holdout_{run}' if mode=='local' else f'crossnode_holdout_{run}');out=case/'vidur_native_dag_v2'
   with (case/'vidur_native_dag_v2.log').open('w') as f:
    subprocess.run([PY,str(R/'staging/scripts/vidur_decode_diagnostic.py'),'--config',str(conf),'--mode','replay','--trace',str(case/'arrival_trace.csv'),'--output-dir',str(out)],cwd=P,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
   actual=Path((out/'run_path.txt').read_text().strip())
   for n in ['request_metrics.csv','batch_metrics.csv','config.json']:shutil.copy2(actual/n,out/n)
   print(mode,run,flush=True)
 s['phase']='complete';save()
except Exception as e:s.update(phase='failed',error=repr(e));save();raise
