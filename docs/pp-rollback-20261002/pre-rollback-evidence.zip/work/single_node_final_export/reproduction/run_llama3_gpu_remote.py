import json,os,subprocess,time,csv
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');s=dict(pid=os.getpid(),phase='starting',started_at_epoch=time.time());M='/mnt/data02/000000/model/Meta-Llama-3-8B-Instruct'
def save():(R/'llama3_gpu_state.json').write_text(json.dumps(s))
save()
try:
 jobs=[('mlp',['/diagnostic/staging/vidur/profiling/cpu_overhead/vllm_051_mlp_profile.py','--model',M,'--tensor-parallel-sizes','1','2','--max-tokens','2048','--vidur-vocab-size','128256','--warmup','20','--repetitions','20','--output','/diagnostic/llama3_mlp.csv']),('attention',['/diagnostic/staging/vidur/profiling/cpu_overhead/vllm_051_attention_profile.py','--model',M,'--tensor-parallel-sizes','1','2','--max-model-len','4096','--max-seq-len','2048','--batch-sizes','1','2','3','4','--prefill-chunk-sizes','32','64','128','256','512','1024','2048','--kv-cache-sizes','0','128','192','512','576','1024','1536','1920','--decode-layout','cuda_graph','--decode-block-table-capacity','4096','--warmup','10','--repetitions','20','--output','/diagnostic/llama3_attention.csv']),('decoder',['/diagnostic/staging/scripts/profile_native_decoder_graph.py','--model',M,'--tensor-parallel-sizes','1','2','--layers','16','32','--batch-sizes','1','2','3','4','--kv-sizes','128','192','512','576','1024','1536','1920','--capacity','4096','--output','/diagnostic/llama3_decoder_raw.csv'])]
 for phase,args in jobs:
  s['phase']=phase;save()
  with (R/f'llama3_{phase}.log').open('w') as f:subprocess.run(['sudo','-n','docker','exec','vidur-operator-residual-20261001','python3',*args],stdout=f,stderr=subprocess.STDOUT,check=True)
 rows=list(csv.DictReader((R/'llama3_decoder_raw.csv').open()))
 for row in rows:
  assert row['model_path']==M;row['model_name']='meta-llama/Meta-Llama-3-8B'
 with (R/'llama3_decoder.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 s['phase']='complete';save()
except Exception as e:s.update(phase='failed',error=repr(e));save();raise
