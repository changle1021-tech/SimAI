"""Measure idle-state primitives after the independent cross-node TP holdout."""
import json,os,subprocess,time
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
state=dict(pid=os.getpid(),phase='waiting',started_at_epoch=time.time())
def save():(R/'spaced_profile_state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 for _ in range(7200):
  phase=json.loads((R/'crossnode_controlled_state.json').read_text())['phase']
  if phase=='complete':break
  if phase=='failed':raise RuntimeError('Cross-node TP validation failed; inspect it before starting another job')
  time.sleep(1)
 else:raise RuntimeError('Prerequisite did not finish')
 state['phase']='profiling';save()
 command=['sudo','-n','docker','exec','vidur-crossnode-residual-20261001','python3',
 '/diagnostic/staging/vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py',
 '--model','/mnt/data02/000000/model/Llama-2-7b-hf-bin-export','--model-name-for-vidur',
 'meta-llama/Llama-2-7b-hf','--tensor-parallel-size','1','--pipeline-parallel-size','2',
 '--profile-http-serving','--executor-backend','ray','--network-transport','socket',
 '--batch-sizes','1','--prompt-tokens','512','--decode-tokens','50','--repetitions','5',
 '--max-model-len','4096','--max-num-seqs','8','--max-num-batched-tokens','4096',
 '--gpu-memory-utilization','0.2','--load-format','auto','--seed','36',
 '--diagnostic-request-interval','10','--output','/diagnostic/crossnode_pp2_spaced_diagnostic.csv']
 state['command']=command;save()
 with (R/'crossnode_pp2_spaced_diagnostic.log').open('x') as log:
  subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 state.update(phase='complete',completed_at_epoch=time.time());save()
except Exception as exc:state.update(phase='failed',error=repr(exc));save();raise
