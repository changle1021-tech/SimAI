import json,os,time,subprocess
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');s=dict(pid=os.getpid(),phase='running',started_at_epoch=time.time())
def save():(R/'decoder_graph_smoke_state.json').write_text(json.dumps(s))
save()
try:
 args=['sudo','-n','docker','exec','vidur-operator-residual-20261001','python3','/diagnostic/staging/scripts/profile_native_decoder_graph.py','--model','/mnt/data02/000000/model/Llama-2-7b-hf-bin-export','--tensor-parallel-sizes','1','--layers','16','--batch-sizes','1','--kv-sizes','512','576','--capacity','4096','--output','/diagnostic/native_decoder_graph_smoke.csv']
 with (R/'decoder_graph_smoke.log').open('w') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)
 s['phase']='complete';save()
except Exception as e:s.update(phase='failed',error=repr(e));save();raise
