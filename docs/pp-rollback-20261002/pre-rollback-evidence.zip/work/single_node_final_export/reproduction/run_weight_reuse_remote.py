import json,os,subprocess,time
from pathlib import Path
R=Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001');s=dict(pid=os.getpid(),phase='running',started_at_epoch=time.time())
def save():(R/'weight_reuse_state.json').write_text(json.dumps(s))
save()
try:
 for ring in [1,16]:
  s['ring']=ring;save()
  args=['sudo','-n','docker','exec','vidur-operator-residual-20261001','python3','/diagnostic/staging/scripts/profile_mlp_weight_reuse.py','--model','/mnt/data02/000000/model/Llama-2-7b-hf-bin-export','--tensor-parallel-sizes','1','2','--num-tokens','1','4','8','512','--layer-weight-ring',str(ring),'--max-tokens','4096','--warmup','20','--repetitions','20','--vidur-vocab-size','32768','--output',f'/diagnostic/mlp_weight_ring_{ring}.csv']
  with (R/f'weight_ring_{ring}.log').open('w') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)
 s['phase']='complete';save()
except Exception as e:s.update(phase='failed',error=repr(e));save();raise
