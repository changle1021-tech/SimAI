#!/usr/bin/env python3
"""Collect three isolated native vLLM measurements from an existing remote container.

This driver performs measurements only. It does not configure or run Vidur, modify
the container, deploy code, or overwrite existing result directories.
"""

import argparse
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/turbo_ops/changle/Files/analysis/pp2_residual_20261001')
SERVER_SCRIPT = '/diagnostic/staging/scripts/vllm_051_server_diagnostic.py'
CLIENT_SCRIPT = '/diagnostic/staging/scripts/vllm_benchmark_client.py'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--case-prefix', required=True)
    parser.add_argument('--container', required=True)
    parser.add_argument('--model-path', required=True)
    parser.add_argument('--served-model', required=True)
    parser.add_argument('--tp', required=True, type=int)
    parser.add_argument('--pp', required=True, type=int)
    parser.add_argument('--unmodified-server', action='store_true')
    parser.add_argument('--prompt-tokens', default=512, type=int)
    parser.add_argument('--decode-tokens', default=50, type=int)
    args = parser.parse_args()
    server_script=('/diagnostic/staging/scripts/vllm_native_api_server.py'
                   if args.unmodified_server else SERVER_SCRIPT)

    if not args.case_prefix.replace('-', '').replace('_', '').isalnum():
        parser.error("--case-prefix must contain only letters, digits, '_' or '-'")
    if args.tp < 1 or args.pp < 1:
        parser.error('--tp and --pp must be positive')

    state_path = ROOT / f'{args.case_prefix}_evaluation_state.json'
    driver_dir = ROOT / f'{args.case_prefix}_driver'
    cases = [ROOT / f'{args.case_prefix}_{i}' for i in range(3)]
    ROOT.mkdir(parents=True, exist_ok=True)
    # Never reuse results or an old PID record from an earlier evaluation.
    if state_path.exists() or driver_dir.exists() or any(case.exists() for case in cases):
        raise FileExistsError('Evaluation output already exists; refusing to overwrite it')
    for case in cases:
        case.mkdir()

    state = {'pid': os.getpid(), 'phase': 'starting', 'started_at_epoch': time.time(),
             'case_prefix': args.case_prefix, 'container': args.container,
             'model_path': args.model_path, 'served_model': args.served_model,
             'tp': args.tp, 'pp': args.pp}

    def save_state():
        state_path.write_text(json.dumps(state, indent=2) + '\n')

    def docker_exec(*command, **kwargs):
        return subprocess.run(['sudo', '-n', 'docker', 'exec', args.container,
                               *command], check=True, **kwargs)

    server = None
    server_log = None
    save_state()
    try:
        launch = [
            'python3', server_script,
            '--diagnostic-output', f'/diagnostic/{args.case_prefix}_driver',
            '--model', args.model_path,
            '--served-model-name', args.served_model,
            '--load-format', 'auto', '--disable-custom-all-reduce',
            '--dtype', 'float16', '--max-model-len', '4096',
            '--tensor-parallel-size', str(args.tp),
            '--pipeline-parallel-size', str(args.pp),
            '--seed', '36', '--distributed-executor-backend', 'ray',
            '--gpu-memory-utilization', '0.8', '--block-size', '16',
            '--max-num-seqs', '8', '--max-num-batched-tokens', '4096',
            '--max-seq-len-to-capture', '4096', '--disable-log-stats',
            '--host', '127.0.0.1', '--port', '8089',
        ]
        (ROOT / f'{args.case_prefix}_server_launch.json').write_text(
            json.dumps(launch, indent=2) + '\n')
        state.update(phase='server_starting')
        save_state()
        server_log = (ROOT / f'{args.case_prefix}_server.log').open('x')
        server = subprocess.Popen(['sudo', '-n', 'docker', 'exec', args.container,
                                   *launch], stdout=server_log, stderr=subprocess.STDOUT)
        state['server_exec_pid'] = server.pid
        save_state()

        for _ in range(120):
            if server.poll() is not None:
                raise RuntimeError('API service exited during startup')
            health = subprocess.run(
                ['sudo', '-n', 'docker', 'exec', args.container, 'python3', '-c',
                 "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8089/health', timeout=2).close()"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if health.returncode == 0:
                break
            time.sleep(2)
        else:
            raise RuntimeError('API health startup timeout')

        for run, case in enumerate(cases):
            state.update(phase='measuring', case=run)
            save_state()
            client = [
                'python3', CLIENT_SCRIPT,
                '--host', '127.0.0.1', '--port', '8089', '--model', args.served_model,
                '--num-requests', '3', '--qps', '0.3', '--prefill-tokens', str(args.prompt_tokens),
                '--decode-tokens', str(args.decode_tokens), '--seed', '36', '--warmup-requests', '5',
                '--ignore-eos', '--output-dir', f'/diagnostic/{case.name}',
                '--output-file', 'vllm.json', '--trace-output-file',
                f'/diagnostic/{case.name}/arrival_trace.csv',
            ]
            (case / 'client_launch.json').write_text(json.dumps(client, indent=2) + '\n')
            with (case / 'client.log').open('x') as log:
                docker_exec(*client, stdout=log, stderr=subprocess.STDOUT)
            result = json.loads((case / 'vllm.json').read_text())
            requests = result.get('requests', [])
            if len(requests) != 3 or any(
                    row.get('actual_completion_tokens') != args.decode_tokens or
                    row.get('actual_prompt_tokens') != args.prompt_tokens for row in requests):
                raise RuntimeError(f'Case {run} failed request/token-count validation')
            if not (case / 'arrival_trace.csv').is_file():
                raise RuntimeError(f'Case {run} did not produce arrival_trace.csv')
            print('MEASURED', run, json.dumps(result.get('summary', {})), flush=True)
        state.update(phase='complete', completed_at_epoch=time.time())
        save_state()
    except Exception as exc:
        state.update(phase='failed', error=repr(exc), failed_at_epoch=time.time())
        save_state()
        raise
    finally:
        # Stop only the vLLM process whose recorded cmdline names this script and prefix.
        stop_check = (
            "import os,signal,sys; "
            f"p='/diagnostic/{args.case_prefix}_driver/server_pid.txt'; "
            "pid=int(open(p).read().strip()); "
            "cmd=open(f'/proc/{pid}/cmdline','rb').read().decode(errors='replace').replace('\\x00',' '); "
            f"script={server_script!r}; prefix={args.case_prefix!r}; "
            "(os.kill(pid,signal.SIGTERM) if script in cmd and prefix in cmd "
            "else sys.exit('refusing to signal PID: cmdline does not match script and prefix'))"
        )
        if server is not None:
            subprocess.run(['sudo', '-n', 'docker', 'exec', args.container,
                            'python3', '-c', stop_check], check=False)
            try:
                server.wait(timeout=30)
            except subprocess.TimeoutExpired:
                state.update(phase='server_stop_timeout', updated_at_epoch=time.time())
                save_state()
        if server_log is not None:
            server_log.close()


if __name__ == '__main__':
    main()
