本包对应 2026-10-01 的单节点 PP 修复。正式运行目录已经安装；此包用于审查、保留证据和复现，不需要再次覆盖正式仓库。

验收单位是用户指定的“多轮实验的 E2E 总体均值”，阈值 ±10%。每组十轮、每轮三个请求，输入 512、输出 50；四组共 120 个原始 vLLM 请求。误差定义为 `(模拟均值 / 实测均值 - 1) × 100%`。实测使用未修改的 vLLM 0.5.1 API server、真实 FP16 权重、单节点 H100；用于定位异步等待问题的 engine 修改没有进入参考服务。

文件说明：

- `repo/`：安装后的源码、四个显式配置、独立原语 profile、测试及两个运行工具。源码是已有 Vidur 仓库的增量文件集合，不能当作完整独立仓库启动。
- `evidence/native/`：四组全部十轮原始 `vllm.json` 和请求到达轨迹。
- `evidence/replay/`：正式路径对应的全部模拟请求指标；回放使用同一批原始到达轨迹。
- `evidence/cpu/`：CPU 原语表、采样前/中/后基线、服务和客户端启动参数。较大的逐步骤 `driver/*/components.json` 和完整日志保留在服务器原目录及完整导出包 `single_node_pp_final_20261001.tar.gz`。
- `evidence/single_node_q9_deployment.json`：部署后的均值验收、源码 SHA256、逐轮误差及缓存路径变化引起的极小随机森林重训差异。
- `evidence/single_node_frozen_holdout_q8_manifest.json`：参考实验前冻结的代码与原语清单；`single_node_corrected_q9_manifest.json` 是随后图外 embedding reduction 计数修正版的清单。q9 沿用同一批原语数值，回放全部参考轨迹。
- `backup/`：本次覆盖前的原始文件；既有 AICB 分支保留。
- `reproduction/`：诊断、冻结实验、回放与导出脚本，含本次服务器绝对路径。复现前按实际目录修改路径。
- `SHA256_manifest.json`：交付包内文件逐个校验清单；`FULL_SERVER_SHA256_manifest.json` 保留服务器完整导出包（含大日志和逐步骤计时）的清单。

正式目录中的运行方法：

```bash
cd /home/turbo_ops/changle/SimAI/vidur-alibabacloud
PYTHONPATH=. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
  /home/turbo_ops/miniconda3/envs/sarathi/bin/python \
  scripts/run_vllm051_profiled_simulation.py \
  --config configs/vllm051_single_node_pp/l2_tp1pp2.json \
  --mode simulate \
  --output-dir benchmark_runs/single_node_pp_reproduce_$(date +%Y%m%d_%H%M%S)
./show_latest_vidur_result.py
```

其他已验证配置是同目录中的 `l2_tp2pp2.json`、`l2_tp1pp3.json`、`l3_tp1pp2.json`。`simulate` 使用配置中的请求 trace，输出目录必须不存在。精确复现某一参考轮次，使用 `--mode replay --trace <该轮 arrival_trace.csv>`；复现证据包时，将配置中 profile 和 trace 的绝对路径改为解包后实际位置。没有给旧全局默认值换上这些数据，后续运行必须显式使用新配置。原 `run_prefill.py` 包含用户 AICB/Qwen 实验，没有改动。

CPU 采集工具入口已经更新：`vllm051:/vllm-workspace/vidur_cpu_overhead/vllm_051_cpu_overhead.py`，工具实现放在同目录的版本目录 `single_node_pp_20261001/`。原容器没有重启。以下为 TP1/PP2 低负载诊断原语的采集方法；它会启动独立测量服务，应在空闲 GPU 上执行：

```bash
python3 /vllm-workspace/vidur_cpu_overhead/vllm_051_cpu_overhead.py \
  --model /mnt/data02/000000/model/Llama-2-7b-hf-bin-export \
  --model-name-for-vidur meta-llama/Llama-2-7b-hf \
  --tensor-parallel-size 1 --pipeline-parallel-size 2 \
  --executor-backend ray --profile-http-serving \
  --dtype float16 --load-format auto --seed 36 \
  --batch-sizes 1 2 3 4 --prompt-tokens 512 --decode-tokens 50 \
  --max-model-len 4096 --max-num-seqs 8 --max-num-batched-tokens 4096 \
  --gpu-memory-utilization 0.8 --repetitions 20 \
  --diagnostic-request-interval 3.3333333333333335 \
  --output /vllm-workspace/vidur_cpu_overhead/new_tp1pp2_cpu.csv
```

这次 PP3 和 Llama‑3 的 CPU 表使用普通 HTTP serving 采样，无诊断间隔；具体完整启动参数保存在证据里。`--diagnostic-request-interval` 描述采样请求节奏，不是增加模拟耗时的参数，正值数据标记为 `http_serving_spaced_diagnostic`，不能当作高负载稳态 profile。采样数据和模拟配置必须使用一致的运行循环模式。默认 `--load-format dummy` 不用于本次真实权重验收，应显式指定 `auto`。

原始用户 shell 只改变 TP，未指定 PP 时始终为 PP1。现在显式传入 `--pipeline-parallel-size` 可以分别采集不同 PP；CSV 同时记录 TP、PP、prefill/decode、执行模式、模型及 rank 布局。Vidur 新路径按这些维度选择，不能继续把同一份 PP1 表用于所有 PP。已有旧 CSV 不会因更新工具自动变成正确的新 profile。

包含 TP NCCL 的 GPU decoder DAG 独立测量示例（在 vLLM 0.5.1 环境执行）：

```bash
PYTHONPATH=vidur/profiling/cpu_overhead python3 \
  scripts/profile_native_decoder_graph_vllm051.py \
  --model /mnt/data02/000000/model/Llama-2-7b-hf-bin-export \
  --model-name-for-vidur meta-llama/Llama-2-7b-hf \
  --tensor-parallel-sizes 2 --layers 16 --batch-sizes 1 2 3 4 \
  --kv-sizes 512 576 --capacity 4096 --include-tp-collectives \
  --warmup 50 --repetitions 50 --output new_tp2_decoder.csv
```

这是原语独立采集，GPU 图包含该阶段各层和实际 TP 组的 NCCL；不能再额外叠加每层的独立 all-reduce。embedding 边界 reduction 在图外，仍单独计数。其他层数、KV 长度、批量、图容量和模型需要相应采样覆盖；缺少覆盖时新路径拒绝猜测。

方法适合通用模拟器的部分是：从模型和并行配置生成实际步骤与依赖，CPU、GPU、通信分别占用对应资源，原语数据明确记录硬件、布局和运行方式；存在缓存/融合/通信交互时测量真实子图，再按边界计数避免重复。扩大适用范围应增加执行后端适配器和原语覆盖，而非拟合请求 E2E。

精度证据范围：本次只验证 Llama 系列 FP16、单节点 H100、上述四种并行配置及 512/50 的低负载请求。没有证明高并发、多活跃 virtual engine、量化、任意模型或跨节点精度。native decoder adapter 当前要求相应 Llama/SILU 结构；其他结构需要适配。跨节点需要另采 rank 放置/链路/协议端点并处理不同主机的时钟域，此次没有开展。逐轮有偏差超过 10% 的情况，均值达标不表示每个请求达标。
