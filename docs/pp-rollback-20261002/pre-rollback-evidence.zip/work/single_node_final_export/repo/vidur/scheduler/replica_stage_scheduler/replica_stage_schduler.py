from typing import Tuple

from vidur.entities import Batch, BatchStage, ExecutionTime
from vidur.execution_time_predictor import BaseExecutionTimePredictor


class ReplicaStageScheduler:
    def __init__(
        self,
        replica_id: int,
        stage_id: int,
        is_last_stage: bool,
        execution_time_predictor: BaseExecutionTimePredictor,
    ) -> None:
        self._replica_id = replica_id
        self._stage_id = stage_id
        self._is_last_stage = is_last_stage
        self._execution_time_predictor = execution_time_predictor

        # 在这个PP stage上等待执行的micro-batch队列
        # Queue of micro-batches waiting for execution on this PP stage
        self._batch_queue = []
        self._is_busy = False

    @property
    def is_last_stage(self) -> bool:
        return self._is_last_stage

    def is_empty(self) -> bool:
        return len(self._batch_queue) == 0

    def add_batch(self, batch: Batch) -> None:
        self._batch_queue.append(batch)

    def on_stage_end(self) -> None:
        self._is_busy = False

    # sw： p batch：time；      flow：time；     d batch： time
    def on_schedule(self, current_time=None) -> Tuple[Batch, BatchStage, ExecutionTime]:
        if self._is_busy or not self._batch_queue:
            return None, None, None

        self._is_busy = True
        batch = self._batch_queue.pop(0)
        # Simulate micro-batch execution on PP stage
        # 模拟 micro-batch 在 PP stage 上的执行
        # TODO(tianhao909): integrate with SimAI for execution time prediction
        # TODO(tianhao909): 接入 SimAI 获取执行时间预测
        execution_time = self._execution_time_predictor.get_execution_time(
            batch,
            self._stage_id,
            current_time=current_time,
        )
        

        # >: total_time =  self.model_time + self._get_cpu_overhead() * 1e-3
    
        total_execution_time = execution_time.total_time
        model_execution_time = execution_time.model_time
        batch_stage = BatchStage(
            batch.id,
            self._replica_id,
            self._stage_id,
            total_execution_time,
            model_execution_time,
            batch.requests,
            batch.num_tokens,
        )

        return batch, batch_stage, execution_time
