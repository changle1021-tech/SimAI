#!/usr/bin/env python3
"""Launch a separate vLLM 0.5.1 API server with in-memory driver timings.

Pass --diagnostic-output DIRECTORY before normal api_server arguments. Stop
this diagnostic server gracefully after clients finish to save driver_steps.json.
No CUDA synchronization, GPU profiler or per-step file writes are introduced.
"""
from __future__ import annotations

import atexit
import contextvars
from importlib.metadata import version
import json
import os
from pathlib import Path
import runpy
import sys
import time


def main():
    index = sys.argv.index('--diagnostic-output')
    output = Path(sys.argv[index + 1])
    del sys.argv[index:index + 2]
    output.mkdir(parents=True, exist_ok=False)
    (output / "server_pid.txt").write_text(str(os.getpid()))
    if version('vllm').split('+')[0] != '0.5.1':
        raise RuntimeError('This probe targets vLLM 0.5.1')
    from vllm.core.scheduler import Scheduler
    from vllm.engine.async_llm_engine import _AsyncLLMEngine

    current = contextvars.ContextVar('diagnostic_step', default=None)
    steps, requests = [], {}
    original_schedule = Scheduler.schedule
    original_step = _AsyncLLMEngine.step_async
    provenance = {'argv': list(sys.argv),
                  'versions': {k: version(k) for k in ('vllm', 'torch', 'ray')},
                  'measurement': 'Driver step_async wall time; CUDA waits are natural. '
                  'In-memory timings; no per-step synchronization or file writes.'}

    def schedule(self, *args, **kwargs):
        start = time.perf_counter_ns()
        result = original_schedule(self, *args, **kwargs)
        schedule_end = time.perf_counter_ns()
        row = current.get()
        if row is not None:
            metadata, scheduled = result
            row.update({'schedule_host_ms': (schedule_end - start) / 1e6,
                        'num_prefill_groups': scheduled.num_prefill_groups,
                        'batch_size': len(scheduled.scheduled_seq_groups),
                        'request_ids': [m.request_id for m in metadata]})
            for m in metadata:
                if m.request_id not in requests:
                    seq = next(iter(m.seq_data.values()))
                    requests[m.request_id] = {'prompt_tokens': seq.get_prompt_len(),
                                             'first_scheduled_ns': start}
            row['schedule_probe_overhead_ms'] = (time.perf_counter_ns() - schedule_end) / 1e6
        return result

    async def step(self, virtual_engine):
        if 'executor_class' not in provenance:
            provenance['executor_class'] = type(self.model_executor).__name__
        row = {'virtual_engine': virtual_engine}
        token = current.set(row)
        start = time.perf_counter_ns()
        try:
            result = await original_step(self, virtual_engine)
        finally:
            end = time.perf_counter_ns()
            current.reset(token)
        row.update({'start_ns': start, 'end_ns': end,
                    'step_wall_ms': (end - start) / 1e6})
        for request_output in result:
            if request_output.finished:
                info = requests[request_output.request_id]
                info['completed_ns'] = end
                info['generated_tokens'] = len(request_output.outputs[0].token_ids)
        steps.append(row)
        row['post_step_probe_overhead_ms'] = (time.perf_counter_ns() - end) / 1e6
        return result

    Scheduler.schedule = schedule
    _AsyncLLMEngine.step_async = step

    def save():
        payload = dict(provenance, requests=requests, steps=steps)
        (output / 'driver_steps.json').write_text(json.dumps(payload, indent=2))
        print('DIAGNOSTIC_SAVED', output / 'driver_steps.json', flush=True)

    atexit.register(save)
    runpy.run_module('vllm.entrypoints.openai.api_server', run_name='__main__')


if __name__ == '__main__':
    main()
