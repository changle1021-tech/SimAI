# PP rollback local inventory

只读盘点；未连接远程、未改仓库或历史证据，未用 Git HEAD 作基线。q9 `backup/repo` 是 PP2 工作之后的 Q9 前备份，不视为 PP 前基线。`unknown` 表示本地缺少明确的 PP 前原件或哈希。

## 证据与计数

- q9 部署状态：`complete`；部署 JSON 记录 27 个运行时代码 SHA。
- Q9 导出 repo payload：51 个文件；另列 PP2 文档和原 CPU 表两项。PP2历史源码包含 8 个成员。
- PP前恢复点仅对已验证的四个基线项标 `yes`；其余没有充分证据的文件标 `unknown`。
- Q9 导出里 27 个运行时代码 SHA 与 deployment JSON 一致。其它 configs/data/scripts/tests 在导出清单里，但部署 JSON 未逐项记录，不宣称已部署。

## 明确 PP 前恢复点

| 项目 | PP 前 SHA256 | 本地恢复来源 | 校验 |
|---|---|---|---|
| `vidur/execution_time_predictor/sklearn_execution_time_predictor.py` | `d9bfa95eb32b16ce8a1f55b751b0b34e26062a43077eceaf52f6b899ff119533` | `work/pp2_predictor_original.py` | 已与指定 SHA 匹配 |
| `vidur/execution_time_predictor/base_execution_time_predictor.py` | `7132b5a695d293f42cd550af1360126c62e4c67a348199cb69b49ab1388fda8d` | `work/single_node_predeploy_sources/vidur/execution_time_predictor/base_execution_time_predictor.py` | 已与指定 SHA 匹配 |
| `vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py` | `34909cd05d3db37398e7a4fcebbbbdb5e2eb6c505caff8dd8ae9475b6690906c` | `work/pp2_cpu_profiler_original.py` | 已与指定 SHA 匹配 |
| `legacy_backup/cpu_overheads.csv` | `a8b605579e07928b686c47b647620a3c7165db34ebf71cfbed25371dc5f8360e` | `outputs/tp_original_path_regression_evidence/legacy_backup/cpu_overheads.csv` | 已与指定 SHA 匹配 |

## 逐文件清单

| 仓库/数据路径 | 类别 | Q9导出 SHA256 | Q9部署记录 | Q9前备份 SHA256 | PP2归档 SHA256 | PP前恢复 | PP前 SHA256 | Q9版本状态 |
|---|---|---|---|---|---|---|---|---|
| `configs/vllm051_single_node_pp/l2_tp1pp2.json` | configs | `0fc94f6cdb9ef276903f2c93656d4adc48733732ddef960876e936234c5efa92` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `configs/vllm051_single_node_pp/l2_tp1pp3.json` | configs | `5b1a0740f13a5c31c641f97ba7ed39cf6ca694adbe5a180e99abcf15f6127834` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `configs/vllm051_single_node_pp/l2_tp2pp2.json` | configs | `31256cb70b2d754afb9eb765f59bdd2161468ecf082e1d742b046a258c47a55b` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `configs/vllm051_single_node_pp/l3_tp1pp2.json` | configs | `f1ab2900167b700ed622a477bd1c7f1382b00e09c6415dab28d5ed1f829d6210` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `data/profiling/vllm051_single_node_pp_20261001/attention_physical_layout.csv` | data/profiles | `9d9efece833658de40a6602f065945566d89eb0496ec18a56c997bd73ea912f6` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `data/profiling/vllm051_single_node_pp_20261001/llama3_attention.csv` | data/profiles | `ad22dd2b5f428e417635b0c729ad01723cc431da2dc77161fc71d91286ce4d74` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `data/profiling/vllm051_single_node_pp_20261001/llama3_decoder.csv` | data/profiles | `eee71d6bc777d5f432684c50bbc80c57ea0c80197c80bb516d6c87605536ff25` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `data/profiling/vllm051_single_node_pp_20261001/llama3_mlp.csv` | data/profiles | `e87fefa6dbcccbfe1ae8e28029829956840f12d0638d8f25abdaf8a75674c455` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `data/profiling/vllm051_single_node_pp_20261001/mlp_native_operators.csv` | data/profiles | `71e97f78a23408cbbea05b83df7cb276054317cc81ce3e823530ad653989b71f` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `data/profiling/vllm051_single_node_pp_20261001/native_collectives_single_node.csv` | data/profiles | `a9e6693292f5f7c296aa6a1f70cd96941fd254b19ba37ea1f77b3f158289ead1` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `data/profiling/vllm051_single_node_pp_20261001/native_decoder_graph_combined_q8.csv` | data/profiles | `00728aaa0af0f3b66f81f0fd18e6d85e8dafbc495e33399330d2944862783d61` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `data/profiling/vllm051_single_node_pp_20261001/single_l2_tp1pp2_q7_cpu_program.csv` | data/profiles | `4ab1ae7002dc637030959085f474f57d9bb312b54fb1ccd08dda953b187fb09c` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `data/profiling/vllm051_single_node_pp_20261001/single_l2_tp1pp3_v2_cpu_program.csv` | data/profiles | `a1551196335b810954082c27fc70cc55cf0554574b3f0a9aaef0b90b56abe894` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `data/profiling/vllm051_single_node_pp_20261001/single_l2_tp2pp2_q7_cpu_program.csv` | data/profiles | `2b22f4eb5054e0b760bc5acbb90b621dd470b6efc5669e62fb2adcf923cab9de` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `data/profiling/vllm051_single_node_pp_20261001/single_l3_tp1pp2_v2_cpu_program.csv` | data/profiles | `3b02b5f0db66bc3e992a0a3a8ac9423abaed54a177557e8ec169db46c8b73dc0` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `scripts/profile_native_decoder_graph_vllm051.py` | scripts | `0ed20d4637a6abe0f123bcfed6df75a9354df4f81623dfa353ae3dfe4aecb70f` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `scripts/run_vllm051_profiled_simulation.py` | scripts | `14c46f5973f88bc7a917faec15705d4ba07cf926f4cbe1a0c6f2a77e92de522f` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `tests/test_collectives_csv_schema.py` | tests | `5a35a7d380573a8eaeadadfd4486aa2f59c67940071e63e3a363076c8db3fb53` | 未记录 | `5a35a7d380573a8eaeadadfd4486aa2f59c67940071e63e3a363076c8db3fb53` | `unknown` | unknown | `unknown` | unknown |
| `tests/test_dispatch_profile_contract.py` | tests | `134f62c8c386cc863d639840af46426ca8ba6af85a6b6871943aa2048ea193e0` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `tests/test_eager_dispatch_program.py` | tests | `4d5bde2b0654467cf64eb4e7ca672f1d88bd83581b73129e77cd7b171eafdbb1` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `tests/test_pp_cpu_profile.py` | tests | `9f4c5118418529cabcfd9e26d2ca2020516bfc912a14a263f5bae0afe1831733` | 未记录 | `145bbf0b98f819d0983e50a109eb705e771818e30b662f66b958432276ce2439` | `145bbf0b98f819d0983e50a109eb705e771818e30b662f66b958432276ce2439` | unknown | `unknown` | unknown |
| `tests/test_pp_profile_contract.py` | tests | `e922b8d463213c4007d068ebf2aa1c53be9c39339cbed1e1998ff9cf33a1f1ee` | 未记录 | `e922b8d463213c4007d068ebf2aa1c53be9c39339cbed1e1998ff9cf33a1f1ee` | `e922b8d463213c4007d068ebf2aa1c53be9c39339cbed1e1998ff9cf33a1f1ee` | unknown | `unknown` | unknown |
| `tests/test_runtime_layout_fidelity.py` | tests | `55a852f14ad957851e092afccb5423db196319c90a30c027dbb63df9ce3fef24` | 未记录 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `tests/test_send_recv_profiling.py` | tests | `59b3512389af5bc6bb5db09cf591cc4e19279f50cb163b843591705a97cee548` | 未记录 | `a4afc84d1441cfad14f1eba4805272a7d0b0eba79dac5fbd3fae1d4216a34127` | `unknown` | unknown | `unknown` | unknown |
| `vidur/config/config.py` | runtime/config and model/predictor configuration; no separate registry module found | `2d450f5b959ae08fa1733eecae99c025020ad09a6a38bd5c4643b7a6c3fdc3b0` | 是 | `d153dc4b990def04059fe676a5bd5f8488cb7668cba4307d4683a1504c07285e` | `unknown` | unknown | `unknown` | unknown |
| `vidur/entities/execution_time.py` | runtime | `a3bcc469f7df330455b2f8deb37d1ae14d79f7beac681402820ab1925df79ac8` | 是 | `9e7f54bd55e521af27c5797188575df05c375f822bb335bdef9919c49c40e3af` | `unknown` | unknown | `unknown` | unknown |
| `vidur/entities/replica.py` | runtime | `3059cbe1e37140f03a6a308d027ed165486d11265a87c2db60ad2935ad7f756d` | 是 | `8522beb3907190e2066d277fa59d6b13280929868df51b5c309cb183d4779276` | `unknown` | unknown | `unknown` | unknown |
| `vidur/events/replica_stage_schedule_event.py` | runtime | `5375ff1a72eb8663d490cd889112cd3d4ecf25603931c68482f45b23df4e8df7` | 是 | `6ed4c6ef1ff9fdded1691a1826b80757585c0d33e1b0f842a2e9d4a538a6e265` | `unknown` | unknown | `unknown` | unknown |
| `vidur/execution_time_predictor/base_execution_time_predictor.py` | runtime | `0d168322d2b703bf8c4bf91aff05233cb27a9b7370d66489fa73754318b89339` | 是 | `7132b5a695d293f42cd550af1360126c62e4c67a348199cb69b49ab1388fda8d` | `unknown` | yes | `7132b5a695d293f42cd550af1360126c62e4c67a348199cb69b49ab1388fda8d` | known_q9_version_differs_from_original |
| `vidur/execution_time_predictor/sklearn_execution_time_predictor.py` | runtime/predictor and CPU-table selection | `4008a34e6e175fd3353cbc5060f94026fb1c811f557c8fcaa8371742419c1d46` | 是 | `5c0196d61bddedf337262b8f6c9efc83d68c5d7965521f4a9942564d7202ebd0` | `5c0196d61bddedf337262b8f6c9efc83d68c5d7965521f4a9942564d7202ebd0` | yes | `d9bfa95eb32b16ce8a1f55b751b0b34e26062a43077eceaf52f6b899ff119533` | known_q9_version_differs_from_original |
| `vidur/profiling/cpu_overhead/dispatch_profile_contract.py` | runtime | `2074e61e401c37a2751921f414a5dcecb649b84273cb2544f21c982a2af4f9cb` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/eager_dispatch_trace.py` | runtime | `8f37156060c1c5e1ca58066eff59b2d0d7f773bb56f9edfac643ab32642f8c72` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/http_profile_arguments.py` | runtime | `0c999d3f893a71e72ee9ebf6bf9f3d6f9fbe9d6efa06b5cff4bf519b0261a04b` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/native_attention_geometry.py` | runtime | `6c7d4eb4a882621fe9365fc7c11d6e85125fb3357e1beaa03831b2a300e3bfce` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/pp_profile_contract.py` | runtime | `f5f79da31c56a190cae5a17c345115a572206eaba2f4d0eb43202e5ea8dc9fa8` | 是 | `3f51504a1fa524f250b3a167d72cf398deb6caa5fbbcc24d845a1a1f7e66689a` | `3f51504a1fa524f250b3a167d72cf398deb6caa5fbbcc24d845a1a1f7e66689a` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/profile_native_collectives.py` | runtime | `f869d5ab05272fb7ea195f4097b8aa2b05db8573b1ad987d9521db4dfa4ece16` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/vllm_051_attention_profile.py` | runtime | `d06927347c98e1f1879fd647c4171eeedad72ab892d9e8a1a69188c90f7dd949` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/vllm_051_cpu_overhead.py` | runtime/CPU profiler | `e85f8fa2f4c02c26bf7bcf2185e9f500f792200a2137c9cd2041641effd66f1b` | 是 | `9a94feff536f044f8ed681b602d434d98603043b7ae14da824ec16dc19539b73` | `9a94feff536f044f8ed681b602d434d98603043b7ae14da824ec16dc19539b73` | yes | `34909cd05d3db37398e7a4fcebbbbdb5e2eb6c505caff8dd8ae9475b6690906c` | known_q9_version_differs_from_original |
| `vidur/profiling/cpu_overhead/vllm_051_http_cpu_profile.py` | runtime | `fe990278822bcfa25fde502fde4db73de965363f7a367e83f0be51842bdee73c` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/vllm_051_http_profile_client.py` | runtime | `8049de3213eecdae64348ca9ed6d8f94f24ab7606dd188958315a65b90e79799` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/vllm_051_http_profile_server.py` | runtime | `7c0d828516f58b18da6f96e403938c750308f9cdc5575f278f522329a47dea44` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/vllm_051_mlp_profile.py` | runtime | `df687de80e6932f1b8808ee896b96c535920c1a07001361e6f4beb0703ddcccb` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/vllm_051_pp_cpu_profile.py` | runtime | `10bd5a9964349061382d8d69d40b5a14f171988e4712b9d7e933a0402a08c02b` | 是 | `5c03b8db4c75115d39f4c0a83855493b4cc76a04df54470bc98020820eb89969` | `5c03b8db4c75115d39f4c0a83855493b4cc76a04df54470bc98020820eb89969` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/vllm_051_pp_worker.py` | runtime | `cc055d8d1a612df10ab5c58850183db38462d5956ba263485d9aad3ee953ce28` | 是 | `8b7464c5492c61ee4197d231af452f24eff79112d6731e696cd03f16ead51a58` | `8b7464c5492c61ee4197d231af452f24eff79112d6731e696cd03f16ead51a58` | unknown | `unknown` | unknown |
| `vidur/profiling/cpu_overhead/vllm_051_profile_common.py` | runtime | `ca287f0034a2fb0b577173b8b766ec317cd2353ef231e4849d12b60e015be46b` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/scheduler/replica_stage_scheduler/replica_stage_schduler.py` | runtime | `6cc25941dc3d63138e6be95355af5cba680a91a198aad98873820973361341c2` | 是 | `42b788c60405da902080531835eaec30d3b6746b927beb5dae064f4829f59b7e` | `unknown` | unknown | `unknown` | unknown |
| `vidur/utils/decoder_graph_profile.py` | runtime | `46bd04a5900c930f233ea4f8e2367e683146c84c09ce75012bbf3930d9c8bd99` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/utils/eager_dispatch_program.py` | runtime | `ce166c1ae734cde5710843f27bf14ec7ee9989ef336a1b4332efa81325a147b7` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/utils/native_collective_profile.py` | runtime | `b88a23038bb47bd2187daceadaea58315d399ef7d05000b018f0caba86900020` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `vidur/utils/param_counter.py` | runtime | `988efcc344b331ded67f91e43ead0a84cf38d3f24bfe9feeeea971498d2668d6` | 是 | `bda6e4132db8b9c2b307d77a3f9260bd8341bd0dd03fce12b0be9914ff09287d` | `unknown` | unknown | `unknown` | unknown |
| `vidur/utils/runtime_layout.py` | runtime | `22ff81274dfd142732ad99c526214a45734878efcf1f4fbee0bbfcbdc65932d7` | 是 | `unknown` | `unknown` | unknown | `unknown` | unknown |
| `docs/pp_cpu_profiling.md` | PP2 documentation | `152ac6b25f3c151122cb431b6768dc44df58765bb584d750a46e01da32568124` | 未记录 | `unknown` | `152ac6b25f3c151122cb431b6768dc44df58765bb584d750a46e01da32568124` | unknown | `unknown` | not_in_q9_repo_payload |
| `[external input] cpu_overheads.csv` | CPU table / external input | `a8b605579e07928b686c47b647620a3c7165db34ebf71cfbed25371dc5f8360e` | 未记录 | `unknown` | `unknown` | yes | `a8b605579e07928b686c47b647620a3c7165db34ebf71cfbed25371dc5f8360e` | verified_original_baseline_copy |

## 关键判断

- 预测器：Q9导出 SHA 与原预测器 SHA 不同；明确原件 `work/pp2_predictor_original.py` 可恢复。Q9前备份/predeploy predictor 的 `5c0196…` 是中间版本，不能替代指定原件。
- base predictor：SHA `7132…` 在 Q9 前备份及 predeploy source 均存在，可恢复；Q9部署版 `0d168…` 是之后的版本。
- CPU profiler：Q9导出 SHA `e85f…` 与指定原件不同；明确原件 `work/pp2_cpu_profiler_original.py` 可恢复。Q9前备份 `9a94…` 是 PP2 改版。
- CPU表：原表 `a8b605…` 已由回归证据 `legacy_backup/cpu_overheads.csv` 验证；Q9 导出中的 profile CSV 属于其它实验数据，不能替代原表。
- 其他路径的 PP 前存在状态、应恢复还是删除、以及远端当前哈希都为 `unknown`。没把 Git HEAD 或较晚的 Q9备份用作真实基线。
- 没发现独立模型注册文件；配置和 predictor 文件在表内按相应类别标注。

详细逐项证据依据和所有路径/哈希见 JSON。
